define({ 


registerDataStream: function() {
    //Define config parameters to register stream.
    var configParams = {
        url: "http://localhost:8081/listStreamData",
        method: "post",
      outputformat: "JSON"
    };

    //Registers the stream.
    var streamObj = kony.stream.registerDataStream("http1.1", configParams, "JSON", this.myCallbackFunctionRegister);
    //Reading the stream Object.
    alert("Stream object is ::" + streamObj);
},
  
   myCallbackFunctionRegister: function(status, data, context) {
    //Execute the logic here
   alert("You have successfully registered a streaming service");
},
  
   deregisterDataStream: function() {
    //Define config parameters to the register stream.
    var configParams = {
        url: "http://localhost:8081/listStreamData",
        method: "post",
        outputformat: "JSON"
    };

    //Registers the stream.
    var streamObj = kony.stream.registerDataStream("http1.1", configParams, "JSON", this.myCallbackFunctionDeregister);


    //Deregisters the data stream with the specified identifier on Windows Phone.
    var status = kony.stream.deregisterDataStream(streamObj);

    //Reading the status.
    alert("Status is ::" + status);
},
  
  myCallbackFunctionDeregister: function()
  {
    alert("You have successfully deregistered the streaming service");
  }
 });