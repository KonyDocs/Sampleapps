define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnRegister **/
    AS_Button_e8861d0bca824dfc8d1976de938effc6: function AS_Button_e8861d0bca824dfc8d1976de938effc6(eventobject) {
        var self = this;
        return self.registerDataStream.call(this);
    },
    /** onClick defined for btnDeregister **/
    AS_Button_g722303050fe444d9df66c19f52f06e0: function AS_Button_g722303050fe444d9df66c19f52f06e0(eventobject) {
        var self = this;
        return self.deregisterDataStream.call(this);
    }
});