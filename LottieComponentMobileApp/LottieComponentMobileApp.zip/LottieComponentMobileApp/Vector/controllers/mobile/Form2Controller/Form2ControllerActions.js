define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** onTouchStart defined for flxTotalBal **/
    AS_FlexContainer_c66b4bbb63e546d189e7b95e6f1ff503: function AS_FlexContainer_c66b4bbb63e546d189e7b95e6f1ff503(eventobject, x, y) {
        var self = this;
        //  Creating the component s object 
        /*
        var multiseriesverticalbar1 = new com.konymp.multiseriesverticalbar(

        {

        	"autogrowMode": kony.flex.AUTOGROW_NONE,

        	"clipBounds": true,

        	"height": "100%",

        	"id": "multiseriesverticalbar1",

        	"isVisible": true,

        	"layoutType": kony.flex.FREE_FORM,

        	"left": "0%",

        	"masterType": constants.MASTER_TYPE_USERWIDGET,

        	"skin": "CopyCopyslFbox1",

        	"top": "0%",

        	"width": "100%"

        }, {}, {});



        multiseriesverticalbar1.enableGrid = true;

        multiseriesverticalbar1.chartData =

        {

        	"data":[	{

        		"label": "FEB 20",

        		"value1": "27",

        		"value2": "55",

        		"value3": "80"

        	},

        	{

        		"label": "MAR 20",

        		"value1": "40",

        		"value2": "30",

        		"value3": "70"

        	},

        	{

        		"label": "APR 20",

        		"value1": "65",

        		"value2": "15",

        		"value3": "85"

        	},

        	{

        		"label": "MAY 20",

        		"value1": "10",

        		"value2": "25",

        		"value3": "60"

        	}

        	]

        };

        multiseriesverticalbar1.chartTitle = "";

        multiseriesverticalbar1.indicatorFontColor = "#FFFFFF";

        multiseriesverticalbar1.barDetails =

        {

        	"data":

        	[

        	{"color": "#8CC7FC", "legendName": "blue"},

        	{"color": "#FFFFFF", "legendName": "white"},

        	{"color": "#3E6F9A", "legendName": "LightBlue"}

        	]

        };

        multiseriesverticalbar1.xAxisTitle = "";

        multiseriesverticalbar1.lowValue = "0";

        multiseriesverticalbar1.highValue = "90";

        multiseriesverticalbar1.enableChartAnimation = true;

        multiseriesverticalbar1.enableLegends = false;

        multiseriesverticalbar1.bgColor = "#1E4495";

        multiseriesverticalbar1.yAxisTitle = "";

        multiseriesverticalbar1.titleFontSize = "6";

        multiseriesverticalbar1.indicatorFontSize = "6";

        multiseriesverticalbar1.legendFontSize = "50%";

        multiseriesverticalbar1.titleFontColor = "#FFFFFF";

        multiseriesverticalbar1.legendFontColor = "#FFFFFF";

        multiseriesverticalbar1.enableStaticPreview = true;

        this.view.flxgrid.add(multiseriesverticalbar1);
        */
    },
    /** onTouchStart defined for flxCashPosition **/
    AS_FlexContainer_f91202b09af24a6da913dd828d67e99a: function AS_FlexContainer_f91202b09af24a6da913dd828d67e99a(eventobject, x, y) {
        var self = this;
        //  Creating the component s object 
        /*
        var multiseriesverticalbar1 = new com.konymp.multiseriesverticalbar(

        {

        	"autogrowMode": kony.flex.AUTOGROW_NONE,

        	"clipBounds": true,

        	"height": "100%",

        	"id": "multiseriesverticalbar1",

        	"isVisible": true,

        	"layoutType": kony.flex.FREE_FORM,

        	"left": "0%",

        	"masterType": constants.MASTER_TYPE_USERWIDGET,

        	"skin": "CopyCopyslFbox1",

        	"top": "0%",

        	"width": "100%"

        }, {}, {});



        multiseriesverticalbar1.enableGrid = true;

        multiseriesverticalbar1.chartData =

        {

        	"data":[	{

        		"label": "FEB 20",

        		"value1": "27",

        		"value2": "55",

        		"value3": "80"

        	},

        	{

        		"label": "MAR 20",

        		"value1": "40",

        		"value2": "30",

        		"value3": "70"

        	},

        	{

        		"label": "APR 20",

        		"value1": "65",

        		"value2": "15",

        		"value3": "85"

        	},

        	{

        		"label": "MAY 20",

        		"value1": "10",

        		"value2": "25",

        		"value3": "60"

        	}

        	]

        };

        multiseriesverticalbar1.chartTitle = "";

        multiseriesverticalbar1.indicatorFontColor = "#FFFFFF";

        multiseriesverticalbar1.barDetails =

        {

        	"data":

        	[

        	{"color": "#8CC7FC", "legendName": "blue"},

        	{"color": "#FFFFFF", "legendName": "white"},

        	{"color": "#3E6F9A", "legendName": "LightBlue"}

        	]

        };

        multiseriesverticalbar1.xAxisTitle = "";

        multiseriesverticalbar1.lowValue = "0";

        multiseriesverticalbar1.highValue = "90";

        multiseriesverticalbar1.enableChartAnimation = true;

        multiseriesverticalbar1.enableLegends = false;

        multiseriesverticalbar1.bgColor = "#1E4495";

        multiseriesverticalbar1.yAxisTitle = "";

        multiseriesverticalbar1.titleFontSize = "6";

        multiseriesverticalbar1.indicatorFontSize = "6";

        multiseriesverticalbar1.legendFontSize = "50%";

        multiseriesverticalbar1.titleFontColor = "#FFFFFF";

        multiseriesverticalbar1.legendFontColor = "#FFFFFF";

        multiseriesverticalbar1.enableStaticPreview = true;

        this.view.flxgrid.add(multiseriesverticalbar1);
        */
    },
    /** onTouchStart defined for flxTotalBalance **/
    AS_FlexContainer_gb6b8f0e56b041c986aa35f6a3d59adc: function AS_FlexContainer_gb6b8f0e56b041c986aa35f6a3d59adc(eventobject, x, y) {
        var self = this;
        //  Creating the component s object 
        /*
        var multiseriesverticalbar1 = new com.konymp.multiseriesverticalbar(

        {

        	"autogrowMode": kony.flex.AUTOGROW_NONE,

        	"clipBounds": true,

        	"height": "100%",

        	"id": "multiseriesverticalbar1",

        	"isVisible": true,

        	"layoutType": kony.flex.FREE_FORM,

        	"left": "0%",

        	"masterType": constants.MASTER_TYPE_USERWIDGET,

        	"skin": "CopyCopyslFbox1",

        	"top": "0%",

        	"width": "100%"

        }, {}, {});



        multiseriesverticalbar1.enableGrid = true;

        multiseriesverticalbar1.chartData =

        {

        	"data":[	{

        		"label": "FEB 20",

        		"value1": "27",

        		"value2": "55",

        		"value3": "80"

        	},

        	{

        		"label": "MAR 20",

        		"value1": "40",

        		"value2": "30",

        		"value3": "70"

        	},

        	{

        		"label": "APR 20",

        		"value1": "65",

        		"value2": "15",

        		"value3": "85"

        	},

        	{

        		"label": "MAY 20",

        		"value1": "10",

        		"value2": "25",

        		"value3": "60"

        	}

        	]

        };

        multiseriesverticalbar1.chartTitle = "";

        multiseriesverticalbar1.indicatorFontColor = "#FFFFFF";

        multiseriesverticalbar1.barDetails =

        {

        	"data":

        	[

        	{"color": "#8CC7FC", "legendName": "blue"},

        	{"color": "#FFFFFF", "legendName": "white"},

        	{"color": "#3E6F9A", "legendName": "LightBlue"}

        	]

        };

        multiseriesverticalbar1.xAxisTitle = "";

        multiseriesverticalbar1.lowValue = "0";

        multiseriesverticalbar1.highValue = "90";

        multiseriesverticalbar1.enableChartAnimation = true;

        multiseriesverticalbar1.enableLegends = false;

        multiseriesverticalbar1.bgColor = "#1E4495";

        multiseriesverticalbar1.yAxisTitle = "";

        multiseriesverticalbar1.titleFontSize = "6";

        multiseriesverticalbar1.indicatorFontSize = "6";

        multiseriesverticalbar1.legendFontSize = "50%";

        multiseriesverticalbar1.titleFontColor = "#FFFFFF";

        multiseriesverticalbar1.legendFontColor = "#FFFFFF";

        multiseriesverticalbar1.enableStaticPreview = true;

        this.view.flxgrid.add(multiseriesverticalbar1);
        */
    },
    /** onTouchStart defined for flxScrollContainer **/
    AS_FlexScrollContainer_be7792affc884f0590ade7826e789e47: function AS_FlexScrollContainer_be7792affc884f0590ade7826e789e47(eventobject, x, y) {
        var self = this;
        //this.view.multiseriesverticalbar.enableChartAnimation = false;
        //this.view.multiseriesverticalbar.enableChartAnimation = true;
    },
    /** onScrollEnd defined for flxScrollContainer **/
    AS_FlexScrollContainer_gd0e5492e529468fa0e5bfcf0dfc9aed: function AS_FlexScrollContainer_gd0e5492e529468fa0e5bfcf0dfc9aed(eventobject) {
        var self = this;
        /*var contentOffsety = this.view.flxScrollContainer.contentOffsetMeasured.y;
        //alert(contentOffsety);
        if (1150<=contentOffsety &&contentOffsety<=1450){
          if (this.view.lblTap3.isVisible === true){
            this.view.lblTap3.onTouchStart();
           
          }
        }

        if (1410<=contentOffsety &&contentOffsety<=1750){
          if (this.view.lbld1.isVisible === false){
            this.view.lblTap2.onTouchStart();
          }
        }



        if (1750<=contentOffsety &&contentOffsety<=2000){
         this.view.Chat.play();
        }*/
    },
    /** postShow defined for Form2 **/
    AS_Form_g9fc45d93bc4464ba8d75da9c49f76d5: function AS_Form_g9fc45d93bc4464ba8d75da9c49f76d5(eventobject) {
        var self = this;
        this.view.Footer1.play();
        this.view.Footer2.stop();
        this.view.Footer3.stop();
        this.view.Footer4.stop();
        self.scheduleTimer.call(this);
        self.setCallBackTimer.call(this);
        self.scheduleTimert1.call(this);
        self.setCallBackTimert1.call(this);
        self.scheduleTimer6.call(this);
        self.setCallBackTimer6.call(this);
        self.scheduleTimer1.call(this);
        self.scheduleTimer2.call(this);
        self.scheduleTimer4.call(this);
        self.scheduleTimer3.call(this);
    },
    /** preShow defined for Form2 **/
    AS_Form_j1d6d7ea651b4032906e5bc9b1649fe3: function AS_Form_j1d6d7ea651b4032906e5bc9b1649fe3(eventobject) {
        var self = this;
        ficocount = p = x = y = a = r = timercountr1 = timercount = timer1count = timer2count = timer3count = 0;
        kony.timer.cancel("timer");
        kony.timer.cancel("timert1");
        kony.timer.cancel("timer1");
        kony.timer.cancel("timer2");
        kony.timer.cancel("timer3");
        kony.timer.cancel("timer4");
        kony.timer.cancel("timer6");
        this.view.imgChecking.clipView = {
            shape: constants.VIEW_CLIP_SHAPE_ROUNDED_RECTANGLE,
            bounds: [5, 5, 5, 5],
            boundsInPixel: true,
            radius: 10
        };
    },
    /** onTouchStart defined for imgFooter1 **/
    AS_Image_b8e5da6a195d4f629a253cf284ae03e7: function AS_Image_b8e5da6a195d4f629a253cf284ae03e7(eventobject, x, y) {
        var self = this;
        this.view.imgFooter1.isVisible = false;
        this.view.Footer1.isVisible = true;
        this.view.Footer1.play();
        this.view.imgFooter2.isVisible = true;
        this.view.Footer2.isVisible = false;
        this.view.imgFooter3.isVisible = true;
        this.view.Footer3.isVisible = false;
        this.view.imgFooter4.isVisible = true;
        this.view.Footer4.isVisible = false;
    },
    /** onTouchStart defined for imgFooter3 **/
    AS_Image_c1a5a52bd9f64498bfb145805e97a9d4: function AS_Image_c1a5a52bd9f64498bfb145805e97a9d4(eventobject, x, y) {
        var self = this;
        this.view.Footer3.play();
        this.view.Footer1.stop();
        this.view.Footer1.play();
        this.view.Footer1.pause();
        this.view.Footer2.stop();
        this.view.Footer2.play();
        this.view.Footer2.pause();
        this.view.Footer4.stop();
        this.view.Footer4.play();
        this.view.Footer4.pause();
    },
    /** onTouchStart defined for imgFooter2 **/
    AS_Image_e150107af37f4fbb94f1ae296fed02b9: function AS_Image_e150107af37f4fbb94f1ae296fed02b9(eventobject, x, y) {
        var self = this;
        this.view.Footer2.play();
        this.view.Footer1.stop();
        this.view.Footer1.play();
        this.view.Footer1.pause();
        this.view.Footer3.stop();
        this.view.Footer3.play();
        this.view.Footer3.pause();
        this.view.Footer4.stop();
        this.view.Footer4.play();
        this.view.Footer4.pause();
    },
    /** onTouchStart defined for imgsettings **/
    AS_Image_f197b8b5838f42c394226d8f90e69501: function AS_Image_f197b8b5838f42c394226d8f90e69501(eventobject, x, y) {
        var self = this;
        var ntf = new kony.mvc.Navigation("Form3");
        ntf.navigate();
    },
    /** onTouchStart defined for imgFooter4 **/
    AS_Image_g4204950c47b42bd8e9305c19368f5c5: function AS_Image_g4204950c47b42bd8e9305c19368f5c5(eventobject, x, y) {
        var self = this;
        this.view.imgFooter4.isVisible = false;
        this.view.Footer4.isVisible = true;
        this.view.Footer4.play();
        this.view.imgFooter2.isVisible = true;
        this.view.Footer2.isVisible = false;
        this.view.imgFooter3.isVisible = true;
        this.view.Footer3.isVisible = false;
        this.view.Footer1.stop();
        this.view.Footer1.play();
        this.view.Footer1.pause();
    },
    /** onTouchStart defined for lblTap **/
    AS_Label_d331eb87fc9748e8b84709941b49461f: function AS_Label_d331eb87fc9748e8b84709941b49461f(eventobject, x, y) {
        var self = this;
        var multiseriesverticalbar1 = new com.konymp.multiseriesverticalbar({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "multiseriesverticalbar1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0%",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "skin": "CopyCopyslFbox1",
            "top": "0%",
            "width": "100%"
        }, {}, {});
        multiseriesverticalbar1.enableGrid = true;
        multiseriesverticalbar1.chartData = {
            "data": [{
                "label": "FEB 20",
                "value1": "27",
                "value2": "55",
                "value3": "80"
            }, {
                "label": "MAR 20",
                "value1": "40",
                "value2": "30",
                "value3": "70"
            }, {
                "label": "APR 20",
                "value1": "65",
                "value2": "15",
                "value3": "85"
            }, {
                "label": "MAY 20",
                "value1": "10",
                "value2": "25",
                "value3": "60"
            }]
        };
        multiseriesverticalbar1.chartTitle = "";
        multiseriesverticalbar1.indicatorFontColor = "#FFFFFF";
        multiseriesverticalbar1.barDetails = {
            "data": [{
                "color": "#8CC7FC",
                "legendName": "blue"
            }, {
                "color": "#FFFFFF",
                "legendName": "white"
            }, {
                "color": "#3E6F9A",
                "legendName": "LightBlue"
            }]
        };
        multiseriesverticalbar1.xAxisTitle = "";
        multiseriesverticalbar1.lowValue = "0";
        multiseriesverticalbar1.highValue = "90";
        multiseriesverticalbar1.enableChartAnimation = true;
        multiseriesverticalbar1.enableLegends = false;
        multiseriesverticalbar1.bgColor = "#1E4495";
        multiseriesverticalbar1.yAxisTitle = "";
        multiseriesverticalbar1.titleFontSize = "6";
        multiseriesverticalbar1.indicatorFontSize = "6";
        multiseriesverticalbar1.legendFontSize = "50%";
        multiseriesverticalbar1.titleFontColor = "#FFFFFF";
        multiseriesverticalbar1.legendFontColor = "#FFFFFF";
        multiseriesverticalbar1.enableStaticPreview = true;
        this.view.flxgrid.add(multiseriesverticalbar1);
    },
    /** onTouchStart defined for lblTap2 **/
    AS_Label_fd444f1dc1934d1290b8b24a975fb594: function AS_Label_fd444f1dc1934d1290b8b24a975fb594(eventobject, x, y) {
        var self = this;
        this.view.lblTap.isVisible = false;
        this.view.lbld1.isVisible = true;
        this.view.lbld12.isVisible = true;
        this.view.lbld2.isVisible = true;
        this.view.lbld22.isVisible = true;
        var DonutChart = new com.konymp.donutchart({
            "clipBounds": true,
            "id": "DonutChart",
            "height": "100%",
            "width": "50%",
            "top": "0%",
            "left": "0%",
            "isVisible": true,
            "zIndex": 1
        }, {}, {});
        /* Setting the component s properties */
        DonutChart.bgColor = "#FFFFFF";
        DonutChart.enableChartAnimation = true;
        DonutChart.enableStaticPreview = true;
        DonutChart.chartData = {
            "data": [{
                "colorCode": "#1B9ED9",
                "label": "Data1",
                "value": "46"
            }, {
                "colorCode": "#E2E9F0",
                "label": "Data2",
                "value": "54"
            }]
        };
        DonutChart.enableLegend = false;
        DonutChart.legendFontColor = "#FFFFFF";
        DonutChart.legendFontSize = "8";
        DonutChart.chartTitle = "";
        DonutChart.titleFontColor = "#FFFFFF";
        DonutChart.titleFontSize = 12;
        /* Adding the component to the form */
        this.view.flxbg.add(DonutChart);
        var DonutChart1 = new com.konymp.donutchart({
            "clipBounds": true,
            "id": "DonutChart1",
            "height": "100%",
            "width": "50%",
            "top": "0%",
            "left": "50%",
            "isVisible": true,
            "zIndex": 1
        }, {}, {});
        /* Setting the component s properties */
        DonutChart1.bgColor = "#FFFFFF";
        DonutChart1.enableChartAnimation = true;
        DonutChart1.enableStaticPreview = true;
        DonutChart1.chartData = {
            "data": [{
                "colorCode": "#57CE42",
                "label": "Data1",
                "value": "25"
            }, {
                "colorCode": "#E2E9F0",
                "label": "Data2",
                "value": "75"
            }]
        };
        DonutChart1.enableLegend = false;
        DonutChart1.legendFontColor = "#FFFFFF";
        DonutChart1.legendFontSize = "8";
        DonutChart1.chartTitle = "";
        DonutChart1.titleFontColor = "#FFFFFF";
        DonutChart1.titleFontSize = 12;
        /* Adding the component to the form */
        this.view.flxbg.add(DonutChart1);
    },
    /** onTouchStart defined for lblTap3 **/
    AS_Label_hf01248d0f484952975f8a2bad9908db: function AS_Label_hf01248d0f484952975f8a2bad9908db(eventobject, x, y) {
        var self = this;
        this.view.lblTap3.isVisible = false;
        var areachart = new com.konymp.areachart({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "id": "areachart",
            "height": "100%",
            "width": "100%",
            "top": "0%",
            "left": "0%",
            "isVisible": true,
            "zIndex": 1,
            "layoutType": kony.flex.FREE_FORM,
            "skin": "slFbox",
            "masterType": constants.MASTER_TYPE_USERWIDGET
        }, {}, {});
        /* Setting the component s properties */
        areachart.graphColor = "#52b7ce";
        areachart.bgColor = "#FFFFFF";
        areachart.lowValue = "600";
        areachart.highValue = "5000";
        areachart.enableStaticPreview = true;
        areachart.enableChartAnimation = true;
        areachart.xAxisTitle = "";
        areachart.yAxisTitle = "";
        areachart.enableGrid = false;
        areachart.enableGridAnimation = false;
        areachart.chartTitle = "";
        areachart.titleFontColor = "#FFFFFF";
        areachart.titleFontSize = "12";
        areachart.chartData = {
            "data": [{
                "dataVal": 900,
                "lblName": "Mar"
            }, {
                "dataVal": 2200,
                "lblName": "May"
            }, {
                "dataVal": 3500,
                "lblName": "Jul"
            }, {
                "dataVal": 1200,
                "lblName": "Sep"
            }, {
                "dataVal": 2700,
                "lblName": "Nov"
            }, {
                "dataVal": 3800,
                "lblName": "Jan"
            }, {
                "dataVal": 1500,
                "lblName": "Mar"
            }]
        };
        this.view.flxBgTotalBalance.add(areachart);
    },
    /** onTouchStart defined for Footer3 **/
    AS_UWI_b78fc1bb4f574e62a21a88fd47bb518f: function AS_UWI_b78fc1bb4f574e62a21a88fd47bb518f(eventobject, x, y) {
        var self = this;
        this.view.Footer3.play();
        this.view.Footer1.stop();
        this.view.Footer1.play();
        this.view.Footer1.pause();
        this.view.Footer2.stop();
        this.view.Footer2.play();
        this.view.Footer2.pause();
        this.view.Footer4.stop();
        this.view.Footer4.play();
        this.view.Footer4.pause();
    },
    /** onTouchStart defined for Footer4 **/
    AS_UWI_ge5b68e16e774b9282e7dab74f49ccbd: function AS_UWI_ge5b68e16e774b9282e7dab74f49ccbd(eventobject, x, y) {
        var self = this;
        this.view.Footer4.play();
        this.view.Footer1.stop();
        this.view.Footer1.play();
        this.view.Footer1.pause();
        this.view.Footer3.stop();
        this.view.Footer3.play();
        this.view.Footer3.pause();
        this.view.Footer2.stop();
        this.view.Footer2.play();
        this.view.Footer2.pause();
    },
    /** onTouchStart defined for Footer1 **/
    AS_UWI_h048c6e4743f4bdeab0bbe1aeecc19da: function AS_UWI_h048c6e4743f4bdeab0bbe1aeecc19da(eventobject, x, y) {
        var self = this;
        this.view.Footer1.play();
        this.view.Footer2.stop();
        this.view.Footer2.play();
        this.view.Footer2.pause();
        this.view.Footer3.stop();
        this.view.Footer3.play();
        this.view.Footer3.pause();
        this.view.Footer4.stop();
        this.view.Footer4.play();
        this.view.Footer4.pause();
    },
    /** onTouchStart defined for Footer2 **/
    AS_UWI_if1080f8926a4d5aaba9aa29e6114394: function AS_UWI_if1080f8926a4d5aaba9aa29e6114394(eventobject, x, y) {
        var self = this;
        this.view.Footer2.play();
        this.view.Footer1.stop();
        this.view.Footer1.play();
        this.view.Footer1.pause();
        this.view.Footer3.stop();
        this.view.Footer3.play();
        this.view.Footer3.pause();
        this.view.Footer4.stop();
        this.view.Footer4.play();
        this.view.Footer4.pause();
    }
});