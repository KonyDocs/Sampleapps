define({ 
  // For Total Balance
  generateAlert: function(){  
  },

  scheduleTimer: function(){  
    kony.timer.schedule("timer",this.generateAlert, 0.01, true);
  },

  cancelTimer: function(){
    kony.timer.cancel("timer");
  },

  callbackfunction: function(){
    this.view.lblAmount.text = "$" + JSON.stringify(x+349);
    x += 5949;
    if(x+1>65428){
      this.view.lblAmount.text = "$65,429";
      kony.timer.cancel("timer");
      x=0;
    }
  },


  setCallBackTimer: function(){
    kony.timer.setCallBack("timer", this.callbackfunction);
  },

  //for cents

  generateAlertt1: function(){  
  },

  scheduleTimert1: function(){  
    kony.timer.schedule("timert1",this.generateAlertt1, 0.01, true);
  },

  cancelTimert1: function(){
    kony.timer.cancel("timert1");
  },

  callbackfunctiont1: function(){
    this.view.lblPower.text = JSON.stringify(p);
    p += 2;
    if(p+1>20){
      this.view.lblPower.text = "2"+ "0";
      kony.timer.cancel("timert1");
      p=0;
    }
  },


  setCallBackTimert1: function(){
    kony.timer.setCallBack("timert1", this.callbackfunctiont1);
  },

  //For Fico score

  generateAlert1: function(){  
  },

  scheduleTimer1: function(){  
    kony.timer.schedule("timer1",this.generateAlert1, 0.05, true);
  },

  cancelTimer1: function(){
    kony.timer.cancel("timer1");
  },

  callbackfunction1: function(){
    this.view.lblFico.text = JSON.stringify(y+19);
    y += 89;
    if(y>704){
      this.view.lblFico.text = "705";
      kony.timer.cancel("timer1");
      y=0;

    }
  },


  setCallBackTimer1: function(){
    kony.timer.setCallBack("timer1", this.callbackfunction1);
  },

  //For Approval

  generateAlert2: function(){  
  },

  scheduleTimer2: function(){  
    kony.timer.schedule("timer2",this.generateAlert2, 0.05, true);
  },

  cancelTimer2: function(){
    kony.timer.cancel("timer2");
  },

  callbackfunction2: function(){
    this.view.lblApproval.text = JSON.stringify(a);
    a += 1;
    if(a>11){
      this.view.lblApproval.text = "12";
      kony.timer.cancel("timer2");
      timercountr = 0;
      a=0;
    }
  },


  setCallBackTimer2: function(){
    kony.timer.setCallBack("timer2", this.callbackfunction2);
  },

  //For requests

  generateAlert3: function(){  
  },

  scheduleTimer3: function(){  
    kony.timer.schedule("timer3",this.generateAlert3, 0.1, true);
  },

  cancelTimer3: function(){
    kony.timer.cancel("timer3");
  },

  callbackfunction3: function(){
    this.view.lblRequest.text = JSON.stringify(r);
    r += 1;
    if(r>4){
      this.view.lblRequest.text = "5";
      kony.timer.cancel("timer3");
      timercountr1=1;
      r=0;
    }
  },


  setCallBackTimer3: function(){
    kony.timer.setCallBack("timer3", this.callbackfunction3);
  },

  //For Spendings

  generateAlert4: function(){  
  },

  scheduleTimer4: function(){  
    kony.timer.schedule("timer4",this.generateAlert4, 0.05, true);
  },

  cancelTimer4: function(){
    kony.timer.cancel("timer4");
  },

  callbackfunction4: function(){
    this.view.lblSpending.text = "$" + JSON.stringify(s);
    s += 666;
    if(s>2273){
      this.view.lblSpending.text = "$2,274";
      kony.timer.cancel("timer4");
      timer2count=1;
      s=0;
    }
  },

  //To get content off set function
  setCallBackTimer4: function(){
    kony.timer.setCallBack("timer4", this.callbackfunction4);
  },


  generateAlert6: function(){  
  },

  scheduleTimer6: function(){  
    kony.timer.schedule("timer6",this.generateAlert6, 0.02, true);
  },

  cancelTimer6: function(){
    kony.timer.cancel("timer6");
  },

  callbackfunction6: function(){
    var contentOffsety = this.view.flxScrollContainer.contentOffsetMeasured.y;
    if (500<=contentOffsety && contentOffsety<=1500 && (timercount === 0 || timercountr1 === 0)){
      if(timercount === 0)
      this.setCallBackTimer2();
      if(timercountr1 === 0)
      this.setCallBackTimer3();
    }
    if (1150<=contentOffsety &&contentOffsety<=1750 && this.view.lblTap3.isVisible === true){
      this.view.lblTap3.onTouchStart();
      timer1count=1;
    }
    if (1410<=contentOffsety && contentOffsety<=1950 && timer2count === 0){
      this.view.lblTap2.onTouchStart();
      this.setCallBackTimer4();
    }
    if (1750<=contentOffsety && contentOffsety<=2200 && timer3count === 0){
      this.view.Chat.play();
      timer3count=1;
    }
    if (2200<=contentOffsety && contentOffsety<=2600 && ficocount === 0){
      this.setCallBackTimer1();
      ficocount=1;
    }
    if (timercount === 1 && timer1count === 1 && timer2count === 1 && timer3count === 1 && ficocount === 1){
      kony.timer.cancel("timer6");
    }
  },


  setCallBackTimer6: function(){
    kony.timer.setCallBack("timer6", this.callbackfunction6);
  },

});