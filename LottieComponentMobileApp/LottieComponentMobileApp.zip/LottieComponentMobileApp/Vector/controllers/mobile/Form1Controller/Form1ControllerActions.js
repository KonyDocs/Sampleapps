define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** onClick defined for btnSignin **/
    AS_Button_c78607318e314b0a8713526ad3b123bc: function AS_Button_c78607318e314b0a8713526ad3b123bc(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("Form2");
        ntf.navigate();
    }
});