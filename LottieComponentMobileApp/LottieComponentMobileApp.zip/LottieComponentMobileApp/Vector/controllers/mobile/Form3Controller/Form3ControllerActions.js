define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** onClick defined for btnSignin **/
    AS_Button_fde6487d232640229eb460b2a551e59b: function AS_Button_fde6487d232640229eb460b2a551e59b(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("Form1");
        ntf.navigate();
    }
});