function AS_Image_f17927654203456cb3e61b80eaff9e8e(eventobject, x, y) {
    var self = this;
    var ntf = new kony.mvc.Navigation("Form3");
    ntf.navigate();
}