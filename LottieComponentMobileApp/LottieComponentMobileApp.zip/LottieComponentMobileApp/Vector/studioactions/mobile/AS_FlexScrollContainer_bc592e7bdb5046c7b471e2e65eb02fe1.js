function AS_FlexScrollContainer_bc592e7bdb5046c7b471e2e65eb02fe1(eventobject, x, y) {
    var self = this;
    //this.view.multiseriesverticalbar.enableChartAnimation = false;
    //this.view.multiseriesverticalbar.enableChartAnimation = true;
}