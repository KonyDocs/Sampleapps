function AS_Label_j75fb1e9441d40acb25f7b9099aed8cf(eventobject, x, y) {
    var self = this;
    this.view.lblTap.isVisible = false;
    this.view.lbld1.isVisible = true;
    this.view.lbld12.isVisible = true;
    this.view.lbld2.isVisible = true;
    this.view.lbld22.isVisible = true;
    var DonutChart = new com.konymp.donutchart({
        "clipBounds": true,
        "id": "DonutChart",
        "height": "100%",
        "width": "50%",
        "top": "0%",
        "left": "0%",
        "isVisible": true,
        "zIndex": 1
    }, {}, {});
    /* Setting the component s properties */
    DonutChart.bgColor = "#FFFFFF";
    DonutChart.enableChartAnimation = true;
    DonutChart.enableStaticPreview = true;
    DonutChart.chartData = {
        "data": [{
            "colorCode": "#1B9ED9",
            "label": "Data1",
            "value": "46"
        }, {
            "colorCode": "#E2E9F0",
            "label": "Data2",
            "value": "54"
        }]
    };
    DonutChart.enableLegend = false;
    DonutChart.legendFontColor = "#FFFFFF";
    DonutChart.legendFontSize = "8";
    DonutChart.chartTitle = "";
    DonutChart.titleFontColor = "#FFFFFF";
    DonutChart.titleFontSize = 12;
    /* Adding the component to the form */
    this.view.flxbg.add(DonutChart);
    var DonutChart1 = new com.konymp.donutchart({
        "clipBounds": true,
        "id": "DonutChart1",
        "height": "100%",
        "width": "50%",
        "top": "0%",
        "left": "50%",
        "isVisible": true,
        "zIndex": 1
    }, {}, {});
    /* Setting the component s properties */
    DonutChart1.bgColor = "#FFFFFF";
    DonutChart1.enableChartAnimation = true;
    DonutChart1.enableStaticPreview = true;
    DonutChart1.chartData = {
        "data": [{
            "colorCode": "#57CE42",
            "label": "Data1",
            "value": "25"
        }, {
            "colorCode": "#E2E9F0",
            "label": "Data2",
            "value": "75"
        }]
    };
    DonutChart1.enableLegend = false;
    DonutChart1.legendFontColor = "#FFFFFF";
    DonutChart1.legendFontSize = "8";
    DonutChart1.chartTitle = "";
    DonutChart1.titleFontColor = "#FFFFFF";
    DonutChart1.titleFontSize = 12;
    /* Adding the component to the form */
    this.view.flxbg.add(DonutChart1);
}