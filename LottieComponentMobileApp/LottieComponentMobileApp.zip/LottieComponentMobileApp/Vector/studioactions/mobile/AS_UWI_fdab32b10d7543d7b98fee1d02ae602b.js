function AS_UWI_fdab32b10d7543d7b98fee1d02ae602b(eventobject, x, y) {
    var self = this;
    this.view.Footer1.play();
    this.view.Footer2.stop();
    this.view.Footer2.play();
    this.view.Footer2.pause();
    this.view.Footer3.stop();
    this.view.Footer3.play();
    this.view.Footer3.pause();
    this.view.Footer4.stop();
    this.view.Footer4.play();
    this.view.Footer4.pause();
}