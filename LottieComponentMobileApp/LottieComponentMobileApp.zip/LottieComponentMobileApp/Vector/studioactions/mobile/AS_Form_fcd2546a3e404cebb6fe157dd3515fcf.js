function AS_Form_fcd2546a3e404cebb6fe157dd3515fcf(eventobject) {
    var self = this;
    this.view.Footer1.play();
    this.view.Footer2.stop();
    this.view.Footer3.stop();
    this.view.Footer4.stop();
    self.scheduleTimer.call(this);
    self.setCallBackTimer.call(this);
    self.scheduleTimert1.call(this);
    self.setCallBackTimert1.call(this);
    self.scheduleTimer6.call(this);
    self.setCallBackTimer6.call(this);
    self.scheduleTimer1.call(this);
    self.scheduleTimer2.call(this);
    self.scheduleTimer4.call(this);
    self.scheduleTimer3.call(this);
}