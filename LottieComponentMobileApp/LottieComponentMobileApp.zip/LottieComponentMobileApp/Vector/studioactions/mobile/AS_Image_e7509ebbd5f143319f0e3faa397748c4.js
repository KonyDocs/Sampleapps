function AS_Image_e7509ebbd5f143319f0e3faa397748c4(eventobject, x, y) {
    var self = this;
    this.view.imgFooter4.isVisible = false;
    this.view.Footer4.isVisible = true;
    this.view.Footer4.play();
    this.view.imgFooter2.isVisible = true;
    this.view.Footer2.isVisible = false;
    this.view.imgFooter3.isVisible = true;
    this.view.Footer3.isVisible = false;
    this.view.Footer1.stop();
    this.view.Footer1.play();
    this.view.Footer1.pause();
}