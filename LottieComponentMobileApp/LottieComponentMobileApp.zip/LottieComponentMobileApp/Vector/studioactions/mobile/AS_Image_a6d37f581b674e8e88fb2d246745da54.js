function AS_Image_a6d37f581b674e8e88fb2d246745da54(eventobject, x, y) {
    var self = this;
    this.view.imgFooter1.isVisible = false;
    this.view.Footer1.isVisible = true;
    this.view.Footer1.play();
    this.view.imgFooter2.isVisible = true;
    this.view.Footer2.isVisible = false;
    this.view.imgFooter3.isVisible = true;
    this.view.Footer3.isVisible = false;
    this.view.imgFooter4.isVisible = true;
    this.view.Footer4.isVisible = false;
}