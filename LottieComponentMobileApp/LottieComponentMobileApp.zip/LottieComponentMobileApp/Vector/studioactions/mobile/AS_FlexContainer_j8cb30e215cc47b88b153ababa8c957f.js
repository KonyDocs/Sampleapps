function AS_FlexContainer_j8cb30e215cc47b88b153ababa8c957f(eventobject, x, y) {
    var self = this;
    //  Creating the component s object 
    /*
var multiseriesverticalbar1 = new com.konymp.multiseriesverticalbar(

{

	"autogrowMode": kony.flex.AUTOGROW_NONE,

	"clipBounds": true,

	"height": "100%",

	"id": "multiseriesverticalbar1",

	"isVisible": true,

	"layoutType": kony.flex.FREE_FORM,

	"left": "0%",

	"masterType": constants.MASTER_TYPE_USERWIDGET,

	"skin": "CopyCopyslFbox1",

	"top": "0%",

	"width": "100%"

}, {}, {});



multiseriesverticalbar1.enableGrid = true;

multiseriesverticalbar1.chartData =

{

	"data":[	{

		"label": "FEB 20",

		"value1": "27",

		"value2": "55",

		"value3": "80"

	},

	{

		"label": "MAR 20",

		"value1": "40",

		"value2": "30",

		"value3": "70"

	},

	{

		"label": "APR 20",

		"value1": "65",

		"value2": "15",

		"value3": "85"

	},

	{

		"label": "MAY 20",

		"value1": "10",

		"value2": "25",

		"value3": "60"

	}

	]

};

multiseriesverticalbar1.chartTitle = "";

multiseriesverticalbar1.indicatorFontColor = "#FFFFFF";

multiseriesverticalbar1.barDetails =

{

	"data":

	[

	{"color": "#8CC7FC", "legendName": "blue"},

	{"color": "#FFFFFF", "legendName": "white"},

	{"color": "#3E6F9A", "legendName": "LightBlue"}

	]

};

multiseriesverticalbar1.xAxisTitle = "";

multiseriesverticalbar1.lowValue = "0";

multiseriesverticalbar1.highValue = "90";

multiseriesverticalbar1.enableChartAnimation = true;

multiseriesverticalbar1.enableLegends = false;

multiseriesverticalbar1.bgColor = "#1E4495";

multiseriesverticalbar1.yAxisTitle = "";

multiseriesverticalbar1.titleFontSize = "6";

multiseriesverticalbar1.indicatorFontSize = "6";

multiseriesverticalbar1.legendFontSize = "50%";

multiseriesverticalbar1.titleFontColor = "#FFFFFF";

multiseriesverticalbar1.legendFontColor = "#FFFFFF";

multiseriesverticalbar1.enableStaticPreview = true;

this.view.flxgrid.add(multiseriesverticalbar1);
*/
}