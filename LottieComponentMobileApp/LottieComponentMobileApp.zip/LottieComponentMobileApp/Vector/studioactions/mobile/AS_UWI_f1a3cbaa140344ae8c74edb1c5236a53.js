function AS_UWI_f1a3cbaa140344ae8c74edb1c5236a53(eventobject, x, y) {
    var self = this;
    this.view.Footer2.play();
    this.view.Footer1.stop();
    this.view.Footer1.play();
    this.view.Footer1.pause();
    this.view.Footer3.stop();
    this.view.Footer3.play();
    this.view.Footer3.pause();
    this.view.Footer4.stop();
    this.view.Footer4.play();
    this.view.Footer4.pause();
}