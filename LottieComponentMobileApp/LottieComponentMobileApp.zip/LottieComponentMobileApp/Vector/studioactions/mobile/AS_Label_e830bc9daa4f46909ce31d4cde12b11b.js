function AS_Label_e830bc9daa4f46909ce31d4cde12b11b(eventobject, x, y) {
    var self = this;
    this.view.lblTap3.isVisible = false;
    var areachart = new com.konymp.areachart({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "id": "areachart",
        "height": "100%",
        "width": "100%",
        "top": "0%",
        "left": "0%",
        "isVisible": true,
        "zIndex": 1,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox",
        "masterType": constants.MASTER_TYPE_USERWIDGET
    }, {}, {});
    /* Setting the component s properties */
    areachart.graphColor = "#52b7ce";
    areachart.bgColor = "#FFFFFF";
    areachart.lowValue = "600";
    areachart.highValue = "5000";
    areachart.enableStaticPreview = true;
    areachart.enableChartAnimation = true;
    areachart.xAxisTitle = "";
    areachart.yAxisTitle = "";
    areachart.enableGrid = false;
    areachart.enableGridAnimation = false;
    areachart.chartTitle = "";
    areachart.titleFontColor = "#FFFFFF";
    areachart.titleFontSize = "12";
    areachart.chartData = {
        "data": [{
            "dataVal": 900,
            "lblName": "Mar"
        }, {
            "dataVal": 2200,
            "lblName": "May"
        }, {
            "dataVal": 3500,
            "lblName": "Jul"
        }, {
            "dataVal": 1200,
            "lblName": "Sep"
        }, {
            "dataVal": 2700,
            "lblName": "Nov"
        }, {
            "dataVal": 3800,
            "lblName": "Jan"
        }, {
            "dataVal": 1500,
            "lblName": "Mar"
        }]
    };
    this.view.flxBgTotalBalance.add(areachart);
}