function AS_FlexScrollContainer_i3abb2fa87994c28a8f8300a2503cf15(eventobject) {
    var self = this;
    /*var contentOffsety = this.view.flxScrollContainer.contentOffsetMeasured.y;
//alert(contentOffsety);
if (1150<=contentOffsety &&contentOffsety<=1450){
  if (this.view.lblTap3.isVisible === true){
    this.view.lblTap3.onTouchStart();
   
  }
}

if (1410<=contentOffsety &&contentOffsety<=1750){
  if (this.view.lbld1.isVisible === false){
    this.view.lblTap2.onTouchStart();
  }
}



if (1750<=contentOffsety &&contentOffsety<=2000){
 this.view.Chat.play();
}*/
}