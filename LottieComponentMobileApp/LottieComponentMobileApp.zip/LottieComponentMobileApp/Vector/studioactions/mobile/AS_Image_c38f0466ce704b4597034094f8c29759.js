function AS_Image_c38f0466ce704b4597034094f8c29759(eventobject, x, y) {
    var self = this;
    this.view.Footer2.play();
    this.view.Footer1.stop();
    this.view.Footer1.play();
    this.view.Footer1.pause();
    this.view.Footer3.stop();
    this.view.Footer3.play();
    this.view.Footer3.pause();
    this.view.Footer4.stop();
    this.view.Footer4.play();
    this.view.Footer4.pause();
}