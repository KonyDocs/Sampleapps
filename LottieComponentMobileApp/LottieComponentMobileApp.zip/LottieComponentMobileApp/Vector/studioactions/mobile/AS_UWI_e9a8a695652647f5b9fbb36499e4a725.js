function AS_UWI_e9a8a695652647f5b9fbb36499e4a725(eventobject, x, y) {
    var self = this;
    this.view.Footer3.play();
    this.view.Footer1.stop();
    this.view.Footer1.play();
    this.view.Footer1.pause();
    this.view.Footer2.stop();
    this.view.Footer2.play();
    this.view.Footer2.pause();
    this.view.Footer4.stop();
    this.view.Footer4.play();
    this.view.Footer4.pause();
}