define({ 

 //Type your controller code here 

 });