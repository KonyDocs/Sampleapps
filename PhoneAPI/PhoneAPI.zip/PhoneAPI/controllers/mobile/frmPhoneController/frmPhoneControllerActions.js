define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnAdd **/
    AS_Button_b55b434b618e426283f953c53f2c9f6f: function AS_Button_b55b434b618e426283f953c53f2c9f6f(eventobject) {
        var self = this;
        return self.CalendarAddEvent.call(this, eventobject);
    },
    /** onClick defined for btnRemove **/
    AS_Button_bd0e7bb3f95b46a5b8bf283c6f5eea4f: function AS_Button_bd0e7bb3f95b46a5b8bf283c6f5eea4f(eventobject) {
        var self = this;
        return self.CalendarRemoveEvent.call(this);
    },
    /** onClick defined for btnEmail **/
    AS_Button_j7e1cc02e1be44eca7065ee3d46b0fe9: function AS_Button_j7e1cc02e1be44eca7065ee3d46b0fe9(eventobject) {
        var self = this;
        return self.emailSend.call(this);
    },
    /** onClick defined for btnEmailWithMedia **/
    AS_Button_cce789d1753f4615bb31211ef40e83d9: function AS_Button_cce789d1753f4615bb31211ef40e83d9(eventobject) {
        var self = this;
        return self.openMediaGalleryForEmail.call(this);
    },
    /** onClick defined for btnSendSMS **/
    AS_Button_b06b1aff190e42659c941d89fb6cccee: function AS_Button_b06b1aff190e42659c941d89fb6cccee(eventobject) {
        var self = this;
        return self.sendSMS.call(this);
    },
    /** onClick defined for CopybtnAdd0cdb0611b155a4d **/
    AS_Button_i180067a5c984f57a763a9d86f3f3737: function AS_Button_i180067a5c984f57a763a9d86f3f3737(eventobject) {
        var self = this;
        return self.hasVibratorSupport.call(this);
    },
    /** onClick defined for CopybtnAdd0fc5bb0f3d2db48 **/
    AS_Button_h5809bb16a624a9f84545c210d65caba: function AS_Button_h5809bb16a624a9f84545c210d65caba(eventobject) {
        var self = this;
        return self.startVibration.call(this);
    },
    /** onClick defined for CopybtnAdd0e58aae67a77546 **/
    AS_Button_abc7292fc9784669a2388c656da47188: function AS_Button_abc7292fc9784669a2388c656da47188(eventobject) {
        var self = this;
        return self.cancelVibration.call(this);
    },
    /** onClick defined for Button0de3b306177fc48 **/
    AS_Button_de52b6812e9c4d5ea2e3c0ea532a567e: function AS_Button_de52b6812e9c4d5ea2e3c0ea532a567e(eventobject) {
        var self = this;
        return self.dial.call(this);
    },
    /** onClick defined for CopybtnAdd0c9d7bc824ed245 **/
    AS_Button_b05267508f13488698fd71fec4671e65: function AS_Button_b05267508f13488698fd71fec4671e65(eventobject) {
        var self = this;
        return self.hapticFeedback.call(this);
    }
});