define({ 


/*****************************************************************
*	Name    : CalendarAddEvent
*	Purpose : To add the calendar event to the device using 'kony.phone.addCalendarEvent' API
******************************************************************/

 CalendarAddEvent:function(eventObj)
{
	try 
	{
		
		var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth()+1; 		
		var yyyy = today.getFullYear();		
		var h=today.getHours();
		var m=today.getMinutes();
		var s=today.getSeconds();
		if(dd<10)
			{dd='0'+dd;}
		if(mm<10)
			{mm='0'+mm;} 		 
		var date = dd+'/'+mm+'/'+yyyy;
		var stime  = h+":"+(parseInt(m)+2).toString()+":"+s;
		this.startTime  =date+" "+stime;
		var ftime = (parseInt(h)+1).toString()+":"+m+":"+s;
		this.finishTime =date+" "+ftime;
		if (eventObj["text"] == "Add calendar event")
		{
			var evtobj={summary:"Event started", start:this.startTime, finish:this.finishTime,alarm:40, access:"public"};
			kony.phone.addCalendarEvent(evtobj);
			alert("Calendar event is added with start time = "+this.startTime+". Please open device calendar to observe this.");
		}
		
		else 
		{
			var evtobj1={summary:"Event started", start:this.startTime, finish:this.finishTime,alarm:40, access:"confidential"};
			kony.phone.addCalendarEvent(evtobj1);
			alert("Calendar event is added in confidential mode with start time = "+this.startTime+".");
			
		}
	}
	catch(PhoneError)
	{
		alert("error in addCalendarEvent:: "+PhoneError);
	}
},
/*****************************************************************
*	Name    : CalendarRemoveEvent
*	Purpose : To remove the calendar event from the device using 'kony.phone.removeCalendarEvent' API
******************************************************************/

 CalendarRemoveEvent:function()
{
		if (this.startTime ==="undefined" || this.startTime ===undefined )
		{
			this.view.lblPhone.text ="Please create the calendar event.";
			return;
		}
		var evtobj={type:"starting",start:this.startTime, finish:this.finishTime};
		var events = kony.phone.findCalendarEvents(evtobj);
		
		kony.phone.removeCalendarEvent(events[0]);
		alert("Calendar event is removed. Please open device calendar to observe this");
},
  
  emailSend:function()
{
	kony.phone.openEmail(["kitchensinkapp@kony.com"],[""],[""],"Feedback on KitchenSink Application 1.1","",false,[]);
},

   openMediaGalleryForEmail:function()
{
	kony.phone.openMediaGallery(this.openMediaGallaeryCallBck,{mimetype:"image/*"});
},

 openMediaGallaeryCallBck:function(rawbytes)
{
	kony.phone.openEmail(["phoneapisample@kony.com"],[""],[""],"","",false,[{mimetype:"image/*",attachment:rawbytes,filename :"IMG_0362.JPG"}]);
},
  
   sendSMS:function()
{
	if(kony.os.deviceInfo().model == "iPhone Simulator")
	{
		alert("Works only on device");
	}
	else
	{
		var phoneNo ="+91 40 12345678"; // This is a dummy number
		var text = "Hi Kony developer";
		kony.phone.sendSMS(phoneNo, text);
	}
},
  
  hasVibratorSupport: function()
  {
if(kony.phone.hasVibratorSupport()===true)
  {
    alert("The device contains a Vibration motor");
  }
  },
  
  dial: function()
  {
    var number =this.view.tbxDial.text;
    kony.phone.dial(number);
  },
  
  startVibration: function()
  {
    if(kony.phone.hasVibratorSupport()===true)
      {
        var vibrationConfig=[{
    "delay": 0,
    "duration": 100,
    "amplitude": 250
}];
        kony.phone.startVibration(vibrationConfig, true);
      }
    else{
        alert("The device does not support vibration");  
    }
  },
  
  cancelVibration: function()
  {
    if(kony.phone.hasVibratorSupport()===true)
      {
        kony.phone.cancelVibration();
      }
    else{
        alert("Click on Start Vibration"); 
    }
  },
  
  hapticFeedback: function(){
  kony.phone.PerformHapticFeedback(5);
}
  
 });

