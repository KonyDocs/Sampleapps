define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnSetItem **/
    AS_Button_ec235a3c2267400494adc0b74cda7c66: function AS_Button_ec235a3c2267400494adc0b74cda7c66(eventobject) {
        var self = this;
        return self.setItemvalues.call(this);
    },
    /** onClick defined for CopybtnSetItem0h6f9c6db89d144 **/
    AS_Button_b79609314a9643f4b2887c0e18773c48: function AS_Button_b79609314a9643f4b2887c0e18773c48(eventobject) {
        var self = this;
        return self.getItemvalues.call(this);
    },
    /** onClick defined for CopybtnSetItem0c2bb99ccbce141 **/
    AS_Button_c40326cf6f1340b4bf8dc6f1c8317eb2: function AS_Button_c40326cf6f1340b4bf8dc6f1c8317eb2(eventobject) {
        var self = this;
        return self.GetKey.call(this);
    },
    /** onClick defined for CopybtnSetItem0hf8fbd88ed854e **/
    AS_Button_f66f20835fb340aea4e5062ac9e59799: function AS_Button_f66f20835fb340aea4e5062ac9e59799(eventobject) {
        var self = this;
        return self.RemoveItem.call(this);
    },
    /** onClick defined for CopybtnSetItem0d43068b30fc94a **/
    AS_Button_b5b590d90f764693af67a3915ae0ca06: function AS_Button_b5b590d90f764693af67a3915ae0ca06(eventobject) {
        var self = this;
        return self.getLength.call(this);
    },
    /** onClick defined for CopybtnSetItem0da11cb2c387646 **/
    AS_Button_bbdb456e692d4233901c5257bf4f4c1e: function AS_Button_bbdb456e692d4233901c5257bf4f4c1e(eventobject) {
        var self = this;
        return self.ClearItem.call(this);
    }
});