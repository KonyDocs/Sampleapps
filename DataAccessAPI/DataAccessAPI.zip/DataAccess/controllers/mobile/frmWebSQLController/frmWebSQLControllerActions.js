define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0g1c5e2d109554a **/
    AS_Button_g276ab276963470da85691fe2138955b: function AS_Button_g276ab276963470da85691fe2138955b(eventobject) {
        var self = this;
        return
    },
    /** onClick defined for CopyButton0a46df5ecc71843 **/
    AS_Button_idd6fa58a0a548139a0c6949c37cf0f4: function AS_Button_idd6fa58a0a548139a0c6949c37cf0f4(eventobject) {
        var self = this;
        return self.doTransactioninsertData.call(this);
    },
    /** onClick defined for CopyButton0a0d20e4f378144 **/
    AS_Button_h71a304b6b7048f0b18b3bfe6039a29d: function AS_Button_h71a304b6b7048f0b18b3bfe6039a29d(eventobject) {
        var self = this;
        return self.doTransactionsqlSelect.call(this);
    },
    /** onClick defined for CopyButton0a9a61fc571e948 **/
    AS_Button_b183aa89f3c2479c9161ab4f23d2f359: function AS_Button_b183aa89f3c2479c9161ab4f23d2f359(eventobject) {
        var self = this;
        return self.doTransactionUpdate.call(this);
    },
    /** onClick defined for CopyButton0c4c381c6f88e44 **/
    AS_Button_be32fa7887fe4c6c8f2bc3e63d10951b: function AS_Button_be32fa7887fe4c6c8f2bc3e63d10951b(eventobject) {
        var self = this;
        return
    },
    /** onClick defined for CopyButton0a08bc93ced6a4a **/
    AS_Button_d46dabca132342849668fb1b6b937bb7: function AS_Button_d46dabca132342849668fb1b6b937bb7(eventobject) {
        var self = this;
        return
    }
});