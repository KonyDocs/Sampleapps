define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for headerButtonLeft **/
    AS_Button_e470ff6cb7fc490298f2f7b4baafea03: function AS_Button_e470ff6cb7fc490298f2f7b4baafea03(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmWebSQL");
        ntf.navigate();
    }
});