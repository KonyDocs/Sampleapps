define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for buttonCopy **/
    AS_Button_d636a37577ae4828a69dd26afdc5abfa: function AS_Button_d636a37577ae4828a69dd26afdc5abfa(eventobject) {
        var self = this;
        return self.toast_call.call(this);
    }
});