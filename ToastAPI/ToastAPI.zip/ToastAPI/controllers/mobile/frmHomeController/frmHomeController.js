define({
toast_call: function()
{
  var a = this.view.tbxCopy.text;
  var ClipData = java.import('android.content.ClipData');
  var ClipboardManager = java.import('android.content.ClipboardManager');
    var Contexts = java.import('android.content.Context');
    var KonyMain = java.import('com.konylabs.android.KonyMain');
    var context = KonyMain.getActivityContext();
    var myClipboard = context.getSystemService(Contexts.CLIPBOARD_SERVICE); 
     
     
    function copyText(text){
     //var text = Form1.lblCopyText.text;
     var myClip = ClipData.newPlainText("text", text);
        myClipboard.setPrimaryClip(myClip);
    }
     
     function pasteText(){
     var abc = myClipboard.getPrimaryClip();
     var item = abc.getItemAt(0);
     var text = item.getText().toString();
     //Form1.lblPastedText.text = text;
    }
  var toast = new kony.ui.Toast({"text": "Your text is copied",
  "duration": constants.TOAST_LENGTH_SHORT});
  toast.show();
  copyText(a);
},  
});