define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** onClick defined for btnRowClick **/
    AS_Button_fa508696e818451b99657282ab6b0277: function AS_Button_fa508696e818451b99657282ab6b0277(eventobject, context) {
        var self = this;
        this.executeOnParent("rowClicked");
    }
});