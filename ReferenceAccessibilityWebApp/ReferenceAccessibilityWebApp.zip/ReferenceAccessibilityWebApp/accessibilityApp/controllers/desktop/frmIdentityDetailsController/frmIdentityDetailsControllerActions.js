define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** onClick defined for navButtons.btnPrimary **/
    AS_Button_a2d59043d62d4055b9cb0da2c194526e: function AS_Button_a2d59043d62d4055b9cb0da2c194526e(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmProductSelection");
        ntf.navigate();
    },
    /** onClick defined for navButtons.btnSecondary2 **/
    AS_Button_da984e41aff040e5a4035ce9b5426c2f: function AS_Button_da984e41aff040e5a4035ce9b5426c2f(eventobject) {
        var self = this;
        kony.store.setItem("PREV_FORM", "frmExistingCustomer");
        var ntf = new kony.mvc.Navigation("frmExistingCustomer");
        ntf.navigate();
    },
    /** onClick defined for navButtons.btnSecondary1 **/
    AS_Button_ded9915edb4e414ba8c8eae320ccb07d: function AS_Button_ded9915edb4e414ba8c8eae320ccb07d(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmPersonalInfod");
        ntf.navigate();
    },
    /** postShow defined for frmIdentityDetails **/
    AS_Form_c303f6d270b04ecaa23cbc902b1aae0e: function AS_Form_c303f6d270b04ecaa23cbc902b1aae0e(eventobject) {
        var self = this;
        self.postShowFunc.call(this);
        kony.store.setItem("PREV_FORM", kony.application.getCurrentForm().id);
        // document.querySelector('input[kw="TextBox2"][kwp*="frmIdentityDetails_IdentityDetails_InternationalAddress_tbxCountry"]').onkeyup = function(e) {
        //   if(e.keyCode === 40) {   
        //     document.querySelector('li[kii="-1,0"][kr="item"]').focus();
        //   }
        // };
        var liCounter = '1';
        document.querySelector('li[kii="-1,0"][kr="item"]').addEventListener('keyup', function(e) {
            if (e.target.tagName.toLowerCase() === 'li' && liCounter === '1' && e.target.ariaRowIndex === '1' && e.keyCode === 38) {
                document.querySelector('input[kw="TextBox2"][kwp*="frmIdentityDetails_IdentityDetails_InternationalAddress_tbxCountry"]').focus();
                this.view.IdentityDetails.InternationalAddress.segCountry.isVisible = false;
            } else if (e.keyCode === 27) {
                document.querySelector('input[kw="TextBox2"][kwp*="frmIdentityDetails_IdentityDetails_InternationalAddress_tbxCountry"]').focus();
            }
            liCounter = e.target.ariaRowIndex;
        });
        // State
        // document.querySelector('input[kw="TextBox2"][kwp*="frmIdentityDetails_IdentityDetails_InternationalAddress_tbxState"]').onkeyup = function(e) {
        //   if(e.keyCode === 40) {   
        //     document.querySelector('li[kii="-1,0"][kr="item"]').focus();
        //   }
        // };
        var liCounter1 = '1';
        document.querySelector('li[kii="-1,0"][kr="item"]').addEventListener('keyup', function(e) {
            if (e.target.tagName.toLowerCase() === 'li' && liCounter1 === '1' && e.target.ariaRowIndex === '1' && e.keyCode === 38) {
                document.querySelector('input[kw="TextBox2"][kwp*="frmIdentityDetails_IdentityDetails_InternationalAddress_tbxState"]').focus();
                this.view.IdentityDetails.InternationalAddress.segCountry.isVisible = false;
            } else if (e.keyCode === 27) {
                document.querySelector('input[kw="TextBox2"][kwp*="frmIdentityDetails_IdentityDetails_InternationalAddress_tbxState"]').focus();
            }
            liCounter1 = e.target.ariaRowIndex;
        });
    },
    /** preShow defined for frmIdentityDetails **/
    AS_Form_fba11383492d4005b43c481525f9909f: function AS_Form_fba11383492d4005b43c481525f9909f(eventobject) {
        var self = this;
        this.view.flxContent.accessibilityConfig = {
            "a11yARIA": {
                "role": "main",
                "tabindex": -1
            }
        };
        this.view.IdentityDetails.lblCountry.top = "20dp";
        var scope = this.view;
        //scopePresonalInfo = this.view;
        this.view.IdentityDetails.atbxTINNumber.tbxAnimatedKA.onBeginEditing = function() {
            scope.IdentityDetails.flxDropdownIdentityType.setVisibility(false);
            var scope1 = scope.IdentityDetails.atbxTINNumber;
            if (scope.IdentityDetails.atbxTINNumber.errorCounter > 0) {
                scope1.lblErrorMsgKA.setVisibility(false);
                scope1.tbxAnimatedKA.accessibilityConfig = {
                    "a11yLabel": "Tax Identification Number"
                };
                scope1.flxUnderlineKA.skin = skins.separator;
                scope1.flxUnderlineKA.height = "2";
                scope1.errorCounter--;
            }
            scope1.callAnimationPlace();
        };
        this.view.IdentityDetails.atbxIdNumber.tbxAnimatedKA.onBeginEditing = function() {
            scope.IdentityDetails.flxDropdownIdentityType.setVisibility(false);
            var scope2 = scope.IdentityDetails.atbxIdNumber;
            if (scope.IdentityDetails.atbxIdNumber.errorCounter > 0) {
                scope2.lblErrorMsgKA.setVisibility(false);
                scope2.tbxAnimatedKA.accessibilityConfig = {
                    "a11yLabel": "ID Number"
                };
                scope2.flxUnderlineKA.skin = skins.separator;
                scope2.flxUnderlineKA.height = "2";
                scope2.errorCounter--;
            }
            scope2.callAnimationPlace();
        };
        self.preShowForm.call(this);
    }
});