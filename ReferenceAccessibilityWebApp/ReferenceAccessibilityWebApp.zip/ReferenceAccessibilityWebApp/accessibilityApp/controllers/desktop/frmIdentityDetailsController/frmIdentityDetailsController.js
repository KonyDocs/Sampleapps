define({
  onNavigate:function(){
    var d1 = [{rowLabel: "Personal Information", rowStatus: "inProgress", currentRow: true}, {rowLabel: "Product Selection", rowStatus: "incomplete", currentRow: false}, {rowLabel: "Verification", rowStatus: "incomplete", currentRow: false}, {rowLabel: "Submit Application", rowStatus: "incomplete", currentRow: false}] ;
    var d2 = {lableStep: "", labelStatus: "Application Number: F8VYD4N", lableStartDate: "Application Started On:  2020-10-08"};
    this.view.Roadmap.setData(d1,d2)
  },
  preShowForm: function () {
    //     this.view.f1.accessibilityConfig = {
    //       "a11yARIA": {
    //         "role": "main"
    //       }
    //     };
    /*this.view.IdentityDetails.atbxTINNumber.tbxAnimatedKA.accessibilityConfig = {
      "a11yARIA": { 
        "aria-labelledby" : "lblAnimatedKA" ,
      },
    }; */
    this.view.flxFooter.accessibilityConfig = {
      "a11yARIA":{
        "role" : "contentinfo",
        "tabindex": -1  
      }
    };
    this.view.IdentityDetails.issueDateComponent.tbxDateInputKA.accessibilityConfig = {
      "a11yLabel":"Issue Date. Optional Field"
    };
    this.view.IdentityDetails.expiryDateComponent.tbxDateInputKA.accessibilityConfig = {
      "a11yLabel":"Expiration Date"
    };
    this.view.IdentityDetails.atbxIdNumber.tbxAnimatedKA.accessibilityConfig = {
      "a11yLabel":"ID Number"
    };
    /* this.view.flxRoadmap.accessibilityConfig = {
      "a11yHidden": true
    }*/
    //      this.view.UserInformationNUO.filterDropdown.tbxDropdownKA.accessibilityConfig = {
    //       "a11yLabel":"Enter the Country Code"
    //     };
    //      this.view.UserInformationNUO.atxtPhoneNumber.tbxAnimatedKA.accessibilityConfig = {
    //       "a11yLabel":"Enter the Phone Number"
    //     };
    //      this.view.YesNoOptionChoser.flxYes.accessibilityConfig = {
    //       "a11yLabel":"Yes Button"
    //     };
    //      this.view.YesNoOptionChoser.flxNo.accessibilityConfig = {
    //       "a11yLabel":"No Button"
    //     };
    this.view.customHeaderNUO.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };

    this.view.customHeaderNUO.imgLogo.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };

    this.view.customfooter.lblCopyright.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    /*this.view.IdentityDetails.lblHeader.accessibilityConfig = {
      "a11yARIA": {
        "role": "heading",
        "aria-level": "2",
        "tabindex": -1
      }
    }; */
    this.view.IdentityDetails.lblSubHeaderTitle.accessibilityConfig = {
      "a11yARIA": {
        "role": "heading",
        //"aria-level": "3",
        "tabindex": -1
      }
    };

    this.view.IdentityDetails.lblSubHeaderTitle1.accessibilityConfig = {
      "a11yARIA": {
        "role": "heading",
        //"aria-level": "3",
        "tabindex": -1
      }
    };

    this.view.IdentityDetails.lblSubHeaderTitle3.accessibilityConfig = {
      "a11yARIA": {
        "role": "heading",
        //"aria-level": "3",
        "tabindex": -1
      }
    };
    document.querySelectorAll('label').forEach(function(elem){
      if(elem.textContent === ""){
        elem.remove();
      }
    });

    // Label TagNames

    this.view.customHeaderNUO.lblOnboarding.accessibilityConfig = {
      "tagName" : "span" ,"a11yARIA": {"tabindex": -1}
    };
    this.view.IdentityDetails.lblHeader.accessibilityConfig = {
      "tagName" : "h1","a11yARIA": {"tabindex": -1}
    };
    this.view.IdentityDetails.lblSubHeaderTitle.accessibilityConfig = {
      "tagName" : "h2","a11yARIA": {"tabindex": -1}
    };
    this.view.IdentityDetails.lblSubHeaderTitle1.accessibilityConfig = {
      "tagName" : "h2","a11yARIA": {"tabindex": -1}
    };
    this.view.IdentityDetails.lblSubHeaderTitle3.accessibilityConfig = {
      "tagName" : "h2","a11yARIA": {"tabindex": -1}
    };
    this.view.IdentityDetails.InternationalAddress.lblAddressTnC.accessibilityConfig = {
      "tagName" : "span","a11yARIA": {"tabindex": -1}
    };
    this.view.customfooter.lblCopyright.accessibilityConfig = {
      "tagName" : "span","a11yARIA": {"tabindex": -1}
    };
    this.view.Roadmap.lblApplicationStatus.accessibilityConfig = {
      "tagName" : "span","a11yARIA": {"tabindex": -1}
    };
    this.view.Roadmap.lblApplicationStartDate.accessibilityConfig = {
      "tagName" : "span","a11yARIA": {"tabindex": -1}
    };











  },
  postShowFunc: function() {
    document.querySelectorAll('img[tabindex="-1"]').forEach(function(el){el.setAttribute("alt","");});
    document.querySelectorAll('input[kwp*="frmIdentityDetails_IdentityDetails_issueDateComponent_tbxDateInputKA"]').forEach(function(el){el.setAttribute("inputmode","number");});
    document.querySelectorAll('input[kwp*="frmIdentityDetails_IdentityDetails_expiryDateComponent_tbxDateInputKA"]').forEach(function(el){el.setAttribute("inputmode","number");});
    //document.querySelectorAll('div[kwp*="Roadmap_flxDropdown"]').forEach(function(el){el.setAttribute("tabindex","0");});
    document.querySelectorAll('img[id="flxRoadmapRowContainer_imgDottedLine"]').forEach(function(elem){elem.setAttribute("alt","");elem.setAttribute("tabindex","-1");});
    document.querySelectorAll('img#frmIdentityDetails_Roadmap_imgDropdown').forEach(function(el){el.setAttribute("alt","");el.setAttribute("tabindex","-1");});
    document.querySelectorAll('span').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('ul[role="grid"]').forEach(function(elem){elem.removeAttribute("tabindex");});
    document.querySelectorAll("label[kw='Button']").forEach(function(el){el.style.outlineOffset = "4px";});
    document.querySelectorAll('h1').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('h2').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('h3').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('h4').forEach(function(el){el.removeAttribute("tabindex");});
	document.querySelectorAll('div').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('div[kwp*="Roadmap_flxDropdown"]').forEach(function(el){el.setAttribute("tabindex","0");});
    document.querySelectorAll('input[type="text"]').forEach(function(el){el.setAttribute("autocomplete","on");});
    document.querySelectorAll('input[kwp*="frmIdentityDetails_IdentityDetails_tbxCountry"]').forEach(function(el){el.setAttribute("autocomplete","county");});
    document.querySelectorAll('input[kwp*="frmIdentityDetails_IdentityDetails_InternationalAddress_tbxAddressLine1"]').forEach(function(el){el.setAttribute("autocomplete","address-line1");});
	document.querySelectorAll('input[kwp*="frmIdentityDetails_IdentityDetails_InternationalAddress_tbxAddressLine2"]').forEach(function(el){el.setAttribute("autocomplete","address-line2");});
	document.querySelectorAll('input[kwp*="frmIdentityDetails_IdentityDetails_InternationalAddress_tbxCountry"]').forEach(function(el){el.setAttribute("autocomplete","county");});
	document.querySelectorAll('input[kwp*="frmIdentityDetails_IdentityDetails_InternationalAddress_tbxZipCode"]').forEach(function(el){el.setAttribute("autocomplete","postal-code");});
    
    document.querySelectorAll('[kwp*="Roadmap_segSections"] ol li').forEach(
      function(elem, index){
        if (index === 0) {
          elem.setAttribute("aria-current","step");
        }
      }
    );
    
    document.querySelectorAll('[tabindex="-1"]').forEach(function(elem){elem.removeAttribute("tabindex");});
	//document.querySelectorAll('input[type="password"]').forEach(function(el){el.removeAttribute("aria-label");});
    /*makeIdUnique("flexcontainer_wrapper");
    makeIdUnique("flxRoadmapRowContainer_flxRoadmapRowContainer");
    makeIdUnique("flxRoadmapRowContainer_flxCurrentRowIndicator");
    makeIdUnique("flxRoadmapRowContainer_flxRowContent");
    makeIdUnique("flxRoadmapRowContainer_flxRowCircle");
    makeIdUnique("flxRoadmapRowContainer_lblRowNumber");
    makeIdUnique("flxRoadmapRowContainer_lblRowName");
    makeIdUnique("flxRoadmapRowContainer_imgDottedLine_span");
    makeIdUnique("flxRoadmapRowContainer_imgDottedLine");
    makeIdUnique("CopyflxDropdownKA_CopyflxDropdownKA");
    makeIdUnique("CopyflxDropdownKA_btnRowClick");
    makeIdUnique("CopyflxDropdownKA_flxCountry");
    makeIdUnique("CopyflxDropdownKA_lblCountryNameKA");
    makeIdUnique("CopyflxDropdownKA_lblLeftBracketKA");
    makeIdUnique("CopyflxDropdownKA_lblCountryCodeKA");
    makeIdUnique("CopyflxDropdownKA_lblRightBracketKA"); */
  }
});