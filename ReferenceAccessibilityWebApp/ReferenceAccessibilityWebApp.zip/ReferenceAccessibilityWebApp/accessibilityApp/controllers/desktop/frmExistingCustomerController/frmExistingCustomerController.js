define({ 
  postshow: function(){
    kony.application.destroyForm("frmIdentityDetails");
    kony.application.destroyForm("frmPersonalInfo");
    kony.application.destroyForm("frmProductSelection");
    /*this.view.rtxESignAgreements.onClick =  this.showAgreement;
    commented out for diff approach*/
    document.querySelectorAll('img[tabindex="-1"]').forEach(function(elem){elem.setAttribute("alt","");});
    document.querySelectorAll('ul[aria-rowcount="8"]').forEach(function(elem){elem.removeAttribute("tabindex");elem.removeAttribute("aria-colcount");elem.removeAttribute("role");});
    document.querySelectorAll('li[role="row"]').forEach(function(el){el.removeAttribute("tabindex");el.removeAttribute("aria-colcount");el.removeAttribute("role");});
    document.querySelectorAll('span').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('h1').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('ul').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('h2').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('h3').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('h4').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('div').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll("li div").forEach(function(el){el.removeAttribute("role");});
    document.querySelectorAll("#esignanchor")[0].addEventListener("keyup", function(event) {
      if (event.keyCode === 13) {
        event.preventDefault();
        kony.application.openURL("https://apply.usbank.com/api/documents/disclosures/ESIGN_Consent_Agreement_Auth.pdf");
      }
    });

    document.querySelectorAll('label').forEach(function(elem){
      if(elem.textContent === ""){
        elem.remove();
      }
    });
    //document.querySelectorAll('label').forEach(function(elem){elem.accessibilityConfig = {"tagName":"div"};});

    var css = 'input[role="link"]:focus { outline: -webkit-focus-ring-color auto 1px!important; outline-color: -webkit-focus-ring-color!important; outline-style: auto!important; outline-width: 1px!important; }';
    css = css+ 'input[kwidgettype="Button"]:focus { outline: -webkit-focus-ring-color auto 1px!important; outline-color: -webkit-focus-ring-color!important; outline-style: auto!important; outline-width: 1px!important; }';
    var style = document.createElement('style');
    if (style.styleSheet) {
      style.styleSheet.cssText = css;
    } else {
      style.appendChild(document.createTextNode(css));
    }
    document.getElementsByTagName('head')[0].appendChild(style);

    this.accessibilityConfigurations();

    ///////////////////////////
    makeIdUnique("flexcontainer_wrapper");  
    makeIdUnique("flxUsefulInfoRow_flxUsefulInfoRow");
    makeIdUnique("flxUsefulInfoRow_lblInfo");
    makeIdUnique("flxUsefulInfoRow_lblDot");
    makeIdUnique("flxUsefulInfoHeader_flxUsefulInfoHeader");
    makeIdUnique("flxUsefulInfoHeader_lblInfoSectionHeader");
    document.querySelector("meta[name='viewport']").setAttribute('content','width=device-width,initial-scale=1.0,maximum-scale=10.0,user-scalable=1.0');
    document.querySelectorAll('img[tabindex="-1"]').forEach(function(elem){elem.setAttribute("alt","");});
    document.querySelectorAll('[tabindex="-1"]').forEach(function(elem){elem.removeAttribute("tabindex");});
  },

  showAgreement: function() {
    kony.application.openURL("https://apply.usbank.com/api/documents/disclosures/ESIGN_Consent_Agreement_Auth.pdf");
  }, 

  accessibilityConfigurations: function() {
    /*Language of Page*/
    window.document.getElementsByTagName("html")[0].setAttribute("lang", "en");
    document.querySelectorAll("#frmExistingCustomer_flxOptions input[type='button'][kwidgettype='Button'][kformname='frmExistingCustomer']").forEach(function(el) {
      el.style.cssText += "outline-offset: 2px;";
    });
    document.querySelectorAll("#frmExistingCustomer_flxOptions div[class='kcell btnPrimaryActive']").forEach(function(el) {
      el.style.cssText += "overflow: initial!important;";
    });
    document.querySelectorAll("label[kw='Button']").forEach(function(el){el.style.outlineOffset = "4px";});
    this.view.imgNewUser.accessibilityConfig = {
      "a11yLabel":"Logo for New Customer",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.customHeaderNUO.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.customHeaderNUO.flxTop.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.customHeaderNUO.flxTopMain.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };

    this.view.customHeaderNUO.imgLogo.accessibilityConfig = {
      "a11yLabel":"Logo for Main Application",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.customfooter.lblCopyright.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    /*this.view.rtxESignAgreements.accessibilityConfig = {
      "a11yARIA": {
        "tabindex": 0  
      }
    }; */
    this.view.imgExistingUser.accessibilityConfig = {
      "a11yLabel":"Logo for Existing Customer",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.usefulInfo.accessibilityConfig = {
      "a11yARIA": {
        "role": "complementary",
        "tabindex": -1
      }
    };

    this.view.flxMain.accessibilityConfig = {
      "a11yARIA": {
        "tabindex": -1
      }
    };
    this.view.f1.accessibilityConfig = {
      "a11yARIA": {
        "role": "main",
        "tabindex": -1
      }
    };
    this.view.f2.accessibilityConfig = {
      "a11yARIA": {
        "role": "contentinfo",
        "tabindex": -1
      }
    };
    
    this.view.lblQuestion.accessibilityConfig = {
      "a11yARIA": {
        "role": "complementary",
        "tabindex": -1
      }
    };
    this.view.lblNotes2.accessibilityConfig = {
      "a11yARIA": {
        "role": "complementary",
        "tabindex": -1
      }
    };
    this.view.lblNewUser2.accessibilityConfig = {
      "a11yARIA": {
        "role": "heading",
        //"aria-level": "2",
        "tabindex": -1
      }
    };
    this.view.usefulInfo.lblHeader.accessibilityConfig = {
      "a11yARIA": {
        "role": "complementary",
        "tabindex": -1
      }
    };

    this.view.usefulInfo.lblHeader.accessibilityConfig = {
      "a11yARIA": {
        "role": "complementary",
        "tabindex": -1
      }
    };

    this.view.flxLeftContent.accessibilityConfig = {
      "a11yARIA":{    
        "role": "contentinfo",
        "tabindex": -1  
      }
    };
    this.view.lblExistingUser2.accessibilityConfig = {
      "tagName":"div",
      "a11yARIA": {
        "role": "heading",
        //"aria-level": "2",
        "tabindex": -1
      }
    };   

  },
  preshow: function(){

    // Label tagName
    this.view.lblExistingUser2.accessibilityConfig = {
      "tagName":"div",
      "a11yARIA": {
        "role": "heading",
        //"aria-level": "2",
        "tabindex": -1
      }
    };   


    this.view.customHeaderNUO.lblSignOut.accessibilityConfig = {
      "tagName":"div","a11yARIA": {"tabindex": -1}
    };
	this.view.lblSROnly.accessibilityConfig = {
      "tagName":"span"
    };
    this.view.customHeaderNUO.lblOnboarding.accessibilityConfig = {
      "tagName":"span","a11yARIA": {"tabindex": -1}
    };
    this.view.customHeaderNUO.lblHeaderMobile.accessibilityConfig = {
      "tagName":"div","a11yARIA": {"tabindex": -1}
    };

    this.view.lblHeader.accessibilityConfig = {
      "tagName":"div","a11yARIA": {"tabindex": -1}
    };
    this.view.lblSeperator.accessibilityConfig = {
      "tagName":"div","a11yARIA": {"tabindex": -1}
    };
    this.view.lblBankName.accessibilityConfig = {
      "tagName":"div","a11yARIA": {"tabindex": -1}
    };
    this.view.lblBankAdd1.accessibilityConfig = {
      "tagName":"div","a11yARIA": {"tabindex": -1}
    };
    this.view.lblBankAdd2.accessibilityConfig = {
      "tagName":"div","a11yARIA": {"tabindex": -1}
    };
    this.view.lblAgreement.accessibilityConfig = {
      "tagName":"div","a11yARIA": {"tabindex": -1}
    };
    this.view.lblAgreementMsg.accessibilityConfig = {
      "tagName":"div","a11yARIA": {"tabindex": -1}
    };
    /*this.view.bannerError.lblError.accessibilityConfig = {
      "tagName":"div","a11yARIA": {"tabindex": -1}
    };*/
    this.view.lblContentHeader.accessibilityConfig = {
      "tagName":"h1","a11yARIA": {"tabindex": -1}
    };
    this.view.lblQuestion.accessibilityConfig = {
      "tagName":"h2","a11yARIA": {"tabindex": -1}
    };
    this.view.lblNewUser2.accessibilityConfig = {
      "tagName":"h3","a11yARIA": {"tabindex": -1}
    };
    this.view.lblNewUser.accessibilityConfig = {
      "tagName":"span","a11yARIA": {"tabindex": -1}
    };
    this.view.lblExistingUser2.accessibilityConfig = {
      "tagName":"h3","a11yARIA": {"tabindex": -1}
    };
    this.view.lblExistingUser.accessibilityConfig = {
      "tagName":"span","a11yARIA": {"tabindex": -1}
    };
    this.view.lblExistingCustomer.accessibilityConfig = {
      "tagName":"div","a11yARIA": {"tabindex": -1}
    };
    this.view.usefulInfo.lblHeader.accessibilityConfig = {
      "tagName":"h2","a11yARIA": {"tabindex": -1}
    };
    this.view.lblNotesHeader.accessibilityConfig = {
      "tagName":"h2","a11yARIA": {"tabindex": -1}
    };
    this.view.lblNotes2.accessibilityConfig = {
      "tagName":"span","a11yARIA": {"tabindex": -1}
    };
    this.view.lblNotes.accessibilityConfig = {
      "tagName":"span","a11yARIA": {"tabindex": -1}
    };
    this.view.customfooter.lblCopyright.accessibilityConfig = {
      "tagName":"span","a11yARIA": {"tabindex": -1}
    };
  }
});