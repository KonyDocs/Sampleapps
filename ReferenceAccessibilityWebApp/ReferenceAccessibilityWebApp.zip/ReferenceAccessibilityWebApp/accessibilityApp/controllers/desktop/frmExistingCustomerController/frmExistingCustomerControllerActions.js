define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** onClick defined for btnNewUser **/
    AS_Button_d189b93ab38d48ecaee34a1ef3b541b9: function AS_Button_d189b93ab38d48ecaee34a1ef3b541b9(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmPersonalInfod");
        ntf.navigate();
    },
    /** postShow defined for frmExistingCustomer **/
    AS_Form_a5e80be9e2494af288a5a7e77ce828a2: function AS_Form_a5e80be9e2494af288a5a7e77ce828a2(eventobject) {
        var self = this;
        this.postshow();
        var PREV_FORM = kony.store.getItem("PREV_FORM");
        if (PREV_FORM !== "frmExistingCustomer" && PREV_FORM !== null) {
            var navigateToForm = new kony.mvc.Navigation(PREV_FORM);
            navigateToForm.navigate();
        } else kony.store.setItem("PREV_FORM", kony.application.getCurrentForm().id);
        // Add javascript event for all tooltips
        obj = document.querySelectorAll(".hasTooltip");
        for (c = 0; c < obj.length; c++) {
            obj[c].setAttribute("tooltipStatus", "inactive");
            obj[c].addEventListener("mouseenter", function() {
                this.setAttribute("tooltipStatus", "active");
            });
            obj[c].addEventListener("mouseleave", function() {
                this.setAttribute("tooltipStatus", "inactive");
            });
            obj[c].addEventListener("focus", function() {
                this.setAttribute("tooltipStatus", "active");
            });
            obj[c].addEventListener("blur", function() {
                this.setAttribute("tooltipStatus", "inactive");
            });
        }
        // Check for all tooltip being active an inactivate them when 'Esc' is pressed
        document.addEventListener("keyup", function(e) {
            if ((e.keyCode || e.which) === 27) {
                obj = document.querySelectorAll(".hasTooltip[tooltipStatus=active]");
                for (c = 0; c < obj.length; c++) {
                    makeInActive(obj[c]);
                }
            }
        });
    },
    /** preShow defined for frmExistingCustomer **/
    AS_Form_g0097f89151847288410c48b231ab5ff: function AS_Form_g0097f89151847288410c48b231ab5ff(eventobject) {
        var self = this;
        this.preshow();
    }
});