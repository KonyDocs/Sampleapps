define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** onClick defined for btnKnowMore1 **/
    AS_Button_a6966fa57d444eeb836adb8c66504e89: function AS_Button_a6966fa57d444eeb836adb8c66504e89(eventobject) {
        var self = this;
        this.onKnowMore(1);
    },
    /** onClick defined for btnKnowMore5 **/
    AS_Button_b69ad4652b63461a93bdaa1df4ad7a84: function AS_Button_b69ad4652b63461a93bdaa1df4ad7a84(eventobject) {
        var self = this;
        this.onKnowMore(5);
    },
    /** onClick defined for btnKnowMore6 **/
    AS_Button_e5bbee9995874a4d96a042a22a16efc7: function AS_Button_e5bbee9995874a4d96a042a22a16efc7(eventobject) {
        var self = this;
        this.onKnowMore(6);
    },
    /** onClick defined for btnSecondary1 **/
    AS_Button_e7864cc3a6a3489f8f82ff5402d56293: function AS_Button_e7864cc3a6a3489f8f82ff5402d56293(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmIdentityDetails");
        ntf.navigate();
    },
    /** onClick defined for btnKnowMore2 **/
    AS_Button_ea2253f6493c433da079268b3d1778e6: function AS_Button_ea2253f6493c433da079268b3d1778e6(eventobject) {
        var self = this;
        this.onKnowMore(2);
    },
    /** onClick defined for btnKnowMore4 **/
    AS_Button_f079ddb42f6a49dc83ea55c711953822: function AS_Button_f079ddb42f6a49dc83ea55c711953822(eventobject) {
        var self = this;
        this.onKnowMore(4);
    },
    /** onClick defined for btnKnowMore3 **/
    AS_Button_fe752cfe9152486facc0ab4ccb415cc5: function AS_Button_fe752cfe9152486facc0ab4ccb415cc5(eventobject) {
        var self = this;
        this.onKnowMore(3);
    },
    /** onClick defined for btnSecondary2 **/
    AS_Button_g7ba7ab8bc434198b1f75c13f5acf657: function AS_Button_g7ba7ab8bc434198b1f75c13f5acf657(eventobject) {
        var self = this;
        kony.store.setItem("PREV_FORM", "frmExistingCustomer");
        var ntf = new kony.mvc.Navigation("frmExistingCustomer");
        ntf.navigate();
    },
    /** onClick defined for btnPrimary **/
    AS_Button_hcc41fea0dce41e4bebce737e1edf68c: function AS_Button_hcc41fea0dce41e4bebce737e1edf68c(eventobject) {
        var self = this;
        kony.store.setItem("PREV_FORM", "frmExistingCustomer");
        var ntf = new kony.mvc.Navigation("frmExistingCustomer");
        ntf.navigate();
    },
    /** onClick defined for flxCheckBox4 **/
    AS_FlexContainer_a20b8f5eb65f4348829324f62bc46af6: function AS_FlexContainer_a20b8f5eb65f4348829324f62bc46af6(eventobject) {
        var self = this;
        this.toggleCheckBox(4);
    },
    /** onClick defined for flxCheckBox3 **/
    AS_FlexContainer_b0025d59c2f94ffaae24fbe0f941f409: function AS_FlexContainer_b0025d59c2f94ffaae24fbe0f941f409(eventobject) {
        var self = this;
        this.toggleCheckBox(3);
    },
    /** onClick defined for flxCheckBox2 **/
    AS_FlexContainer_c9335158c48b438aa2b58f37fa787103: function AS_FlexContainer_c9335158c48b438aa2b58f37fa787103(eventobject) {
        var self = this;
        this.toggleCheckBox(2);
    },
    /** onClick defined for flxDropDown2 **/
    AS_FlexContainer_db32bda5371a45f7b6675623ec64b63b: function AS_FlexContainer_db32bda5371a45f7b6675623ec64b63b(eventobject) {
        var self = this;
        this.productAccordion2();
    },
    /** onClick defined for flxCheckBox5 **/
    AS_FlexContainer_db33125ea01049afafb7ca49c892453f: function AS_FlexContainer_db33125ea01049afafb7ca49c892453f(eventobject) {
        var self = this;
        this.toggleCheckBox(5);
    },
    /** onClick defined for flxDropDown1 **/
    AS_FlexContainer_faf48e8dc84047ecb6316845ee586ff3: function AS_FlexContainer_faf48e8dc84047ecb6316845ee586ff3(eventobject) {
        var self = this;
        this.productAccordion1();
    },
    /** onClick defined for flxCheckBox1 **/
    AS_FlexContainer_g27afbf34dc44a15942d5cfc6c381f50: function AS_FlexContainer_g27afbf34dc44a15942d5cfc6c381f50(eventobject) {
        var self = this;
        this.toggleCheckBox(1);
    },
    /** onClick defined for flxCheckBox6 **/
    AS_FlexContainer_g978eeae7a5c47ae9fe0519a6eb368ac: function AS_FlexContainer_g978eeae7a5c47ae9fe0519a6eb368ac(eventobject) {
        var self = this;
        this.toggleCheckBox(6);
    },
    /** postShow defined for frmProductSelection **/
    AS_Form_c3a743f642b74471a927ddb97cb454b1: function AS_Form_c3a743f642b74471a927ddb97cb454b1(eventobject) {
        var self = this;
        self.postShowFunc.call(this);
        document.querySelectorAll('label').forEach(function(elem) {
            if (elem.textContent === "") {
                elem.remove();
            }
        });
        kony.store.setItem("PREV_FORM", kony.application.getCurrentForm().id);
    },
    /** preShow defined for frmProductSelection **/
    AS_Form_ja031b84e5c543ceb4402cac16e0387f: function AS_Form_ja031b84e5c543ceb4402cac16e0387f(eventobject) {
        var self = this;
        self.preShowFun.call(this);
    }
});