define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** onClick defined for btnRowClick **/
    AS_Button_f65de1b797f44751b754da64bd8b5682: function AS_Button_f65de1b797f44751b754da64bd8b5682(eventobject, context) {
        var self = this;
        this.executeOnParent("idTypeRowClicked");
    }
});