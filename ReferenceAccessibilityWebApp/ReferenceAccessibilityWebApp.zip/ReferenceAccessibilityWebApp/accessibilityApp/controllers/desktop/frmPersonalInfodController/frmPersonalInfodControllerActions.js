define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** onClick defined for navButtons.btnSecondary2 **/
    AS_Button_a1d3a386d56b403dab9429ceebcf352d: function AS_Button_a1d3a386d56b403dab9429ceebcf352d(eventobject) {
        var self = this;
        kony.store.setItem("PREV_FORM", "frmExistingCustomer");
        var ntf = new kony.mvc.Navigation("frmExistingCustomer");
        ntf.navigate();
    },
    /** onClick defined for navButtons.btnSecondary1 **/
    AS_Button_bb3da333926e4d42a799ca5130f82a67: function AS_Button_bb3da333926e4d42a799ca5130f82a67(eventobject) {
        var self = this;
        kony.store.setItem("PREV_FORM", "frmExistingCustomer");
        var ntf = new kony.mvc.Navigation("frmExistingCustomer");
        ntf.navigate();
    },
    /** onClick defined for navButtons.btnPrimary **/
    AS_Button_c617e375817649fbb6fd6fbacdb9250f: function AS_Button_c617e375817649fbb6fd6fbacdb9250f(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmIdentityDetails");
        ntf.navigate();
    },
    /** postShow defined for frmPersonalInfod **/
    AS_Form_a5976c2477f34476bbd151a3edab84bc: function AS_Form_a5976c2477f34476bbd151a3edab84bc(eventobject) {
        var self = this;
        self.postShowFunc.call(this);
        kony.store.setItem("PREV_FORM", kony.application.getCurrentForm().id);
        document.querySelector('input[kw="TextBox2"][kwp*="frmPersonalInfod_UserInformationNUO_filterDropdown_tbxDropdownKA"]').onkeyup = function(e) {
            //   if(e.keyCode === 40) {   
            //     document.querySelector('li[kii="-1,0"]').focus();
            //     //document.querySelector('li"]').focus();
            //     //document.querySelector('input[kw="TextBox2"][kwp*="frmPersonalInfod_UserInformationNUO_filterDropdown_tbxDropdownKA"]').focus();
            //   }
        };
        var liCounter = '1';
        //document.querySelector('ul[role="grid"][kv="tabelview"]').addEventListener('keyup', function (e)  {
        //document.querySelector('li[kii="-1,0"][role="row"]').onkeyup = function(e){
        document.querySelector('li[kii="-1,0"]').addEventListener('keyup', function(e) {
            if (e.target.tagName.toLowerCase() === 'li' && liCounter === '1' && e.target.ariaRowIndex === '1' && e.keyCode === 38) {
                document.querySelector('input[kw="TextBox2"][kwp*="frmPersonalInfod_UserInformationNUO_filterDropdown_tbxDropdownKA"]').focus();
                this.view.UserInformationNUO.filterDropdown.segDropdownKA.isVisible = false;
            } else if (e.keyCode === 27) {
                document.querySelector('input[kw="TextBox2"][kwp*="frmPersonalInfod_UserInformationNUO_filterDropdown_tbxDropdownKA"]').focus();
            }
            liCounter = e.target.ariaRowIndex;
        });
    },
    /** preShow defined for frmPersonalInfod **/
    AS_Form_jc404c9f3c5f4e55b56fa5f9e10c9928: function AS_Form_jc404c9f3c5f4e55b56fa5f9e10c9928(eventobject) {
        var self = this;
        var scope = this.view;
        //scopePresonalInfo = this.view;
        this.view.UserInformationNUO.atxtPhoneNumber.tbxAnimatedKA.onBeginEditing = function() {
            scope.UserInformationNUO.filterDropdown.flxDropdownKA.setVisibility(false);
            scope.UserInformationNUO.filterDropdown.tbxDropdownKA.accessibilityConfig = {
                "a11yLabel": "Country Code",
                "a11yARIA": {
                    "aria-haspopup": "listbox",
                    "aria-expanded": "false",
                },
                "role": "combobox"
            };
            var scope1 = scope.UserInformationNUO.atxtPhoneNumber;
            if (scope.UserInformationNUO.atxtPhoneNumber.errorCounter > 0) {
                scope1.lblErrorMsgKA.setVisibility(false);
                scope1.flxUnderlineKA.skin = skins.separator;
                scope1.flxUnderlineKA.height = "2";
                scope1.errorCounter--;
            }
            scope1.callAnimationPlace();
        };
        this.view.UserInformationNUO.atbxEmail.tbxAnimatedKA.onBeginEditing = function() {
            scope.UserInformationNUO.filterDropdown.flxDropdownKA.setVisibility(false);
            scope.UserInformationNUO.filterDropdown.tbxDropdownKA.accessibilityConfig = {
                "a11yLabel": "Country Code",
                "a11yARIA": {
                    "aria-haspopup": "listbox",
                    "aria-expanded": "false",
                },
                "role": "combobox"
            };
            var scope2 = scope.UserInformationNUO.atbxEmail;
            if (scope.UserInformationNUO.atbxEmail.errorCounter > 0) {
                scope2.lblErrorMsgKA.setVisibility(false);
                scope2.flxUnderlineKA.skin = skins.separator;
                scope2.flxUnderlineKA.height = "2";
                scope2.errorCounter--;
            }
            scope2.callAnimationPlace();
        };
        this.view.UserInformationNUO.atbxLastName.tbxAnimatedKA.onBeginEditing = function() {
            scope.UserInformationNUO.filterDropdown.flxDropdownKA.setVisibility(false);
            scope.UserInformationNUO.filterDropdown.tbxDropdownKA.accessibilityConfig = {
                "a11yLabel": "Country Code",
                "a11yARIA": {
                    "aria-haspopup": "listbox",
                    "aria-expanded": "false",
                },
                "role": "combobox"
            };
            var scope3 = scope.UserInformationNUO.atbxLastName;
            if (scope.UserInformationNUO.atbxLastName.errorCounter > 0) {
                scope3.lblErrorMsgKA.setVisibility(false);
                scope3.flxUnderlineKA.skin = skins.separator;
                scope3.flxUnderlineKA.height = "2";
                scope3.errorCounter--;
            }
            scope3.callAnimationPlace();
        };
        this.view.UserInformationNUO.atbxFirstName.tbxAnimatedKA.onBeginEditing = function() {
            scope.UserInformationNUO.filterDropdown.flxDropdownKA.setVisibility(false);
            scope.UserInformationNUO.filterDropdown.tbxDropdownKA.accessibilityConfig = {
                "a11yLabel": "Country Code",
                "a11yARIA": {
                    "aria-haspopup": "listbox",
                    "aria-expanded": "false",
                },
                "role": "combobox"
            };
            var scope4 = scope.UserInformationNUO.atbxFirstName;
            if (scope.UserInformationNUO.atbxFirstName.errorCounter > 0) {
                scope4.lblErrorMsgKA.setVisibility(false);
                scope4.flxUnderlineKA.skin = skins.separator;
                scope4.flxUnderlineKA.height = "2";
                scope4.errorCounter--;
            }
            scope4.callAnimationPlace();
        };
        self.preShowForm.call(this);
    }
});