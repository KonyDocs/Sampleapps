define({ 
  onNavigate:function(){
    var d1 = [{rowLabel: "Personal Information", rowStatus: "inProgress", currentRow: true}, {rowLabel: "Product Selection", rowStatus: "incomplete", currentRow: false}, {rowLabel: "Verification", rowStatus: "incomplete", currentRow: false}, {rowLabel: "Submit Application", rowStatus: "incomplete", currentRow: false}] ;
    var d2 = {lableStep: "", labelStatus: "Application Number: F8VYD4N", lableStartDate: "Application Started On:  2020-10-08"};
    this.view.Roadmap.setData(d1,d2);
  },
  preShowForm: function () {
    /*data = [
    {
        "lblRowName": {
            "text": "Personal Information",
            "skin": "lblTitle15",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "imgRowDone": {
            "isVisible": false
        },
        "lblRowNumber": {
            "text": "1",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "flxRowCircle": {
            "skin": "flxInProgressCircleRoadmap"
        },
        "lblInProgress": {
            "text": "In Progress",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "flxCurrentRowIndicator": {
            "skin": "flxInProgressRowRoadmap"
        },
        "imgDottedLine": {
            "isVisible": false
        },
        "flxRowContent": {
            "top": "0dp"
        },
        "height": "55dp"
    },
    {
        "lblRowName": {
            "text": "Product Selection",
            "skin": "lblTitle15",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "imgRowDone": {
            "isVisible": false
        },
        "lblRowNumber": {
            "text": "2",
            "skin": "lblTitle15",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "flxRowCircle": {
            "skin": "flxInactiveCircleRoadmap"
        },
        "lblInProgress": {
            "text": "Pending",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "flxCurrentRowIndicator": {
            "skin": "slFbox"
        },
        "imgDottedLine": {
            "isVisible": true
        },
        "flxRowContent": {
            "top": "5dp"
        }
    },
    {
        "lblRowName": {
            "text": "Verification",
            "skin": "lblTitle15",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "imgRowDone": {
            "isVisible": false
        },
        "lblRowNumber": {
            "text": "3",
            "skin": "lblTitle15",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "flxRowCircle": {
            "skin": "flxInactiveCircleRoadmap"
        },
        "lblInProgress": {
            "text": "Pending",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "flxCurrentRowIndicator": {
            "skin": "slFbox"
        },
        "imgDottedLine": {
            "isVisible": true
        },
        "flxRowContent": {
            "top": "5dp"
        }
    },
    {
        "lblRowName": {
            "text": "Submit Application",
            "skin": "lblTitle15",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "imgRowDone": {
            "isVisible": false
        },
        "lblRowNumber": {
            "text": "4",
            "skin": "lblTitle15",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "flxRowCircle": {
            "skin": "flxInactiveCircleRoadmap"
        },
        "lblInProgress": {
            "text": "Pending",
            "accessibilityConfig": {
                "tagName": "span"
            }
        },
        "flxCurrentRowIndicator": {
            "skin": "slFbox"
        },
        "imgDottedLine": {
            "isVisible": true
        },
        "flxRowContent": {
            "top": "5dp"
        }
    }
];*/
    //this.view.Roadmap.segSections.setData(data);

    this.view.f1.accessibilityConfig = {
      "a11yARIA": {
        "role": "main",
        "tabindex": -1
      }
    };
    this.view.flxContentProcedure.accessibilityConfig = {
      "a11yARIA":{
        "role": "contentinfo",
        "tabindex": -1  
      }
    };
    /* this.view.flxRoadmap.accessibilityConfig = {
      "a11yHidden": true
    } */
    this.view.UserInformationNUO.atbxFirstName.tbxAnimatedKA.accessibilityConfig = {
      "a11yLabel":"First Name"
    };
    this.view.UserInformationNUO.atbxLastName.tbxAnimatedKA.accessibilityConfig = {
      "a11yLabel":"Last Name"
    };
    this.view.UserInformationNUO.DateInput.tbxDateInputKA.accessibilityConfig = {
      "a11yLabel":"Date of Birth"
    };
    this.view.UserInformationNUO.atbxEmail.tbxAnimatedKA.accessibilityConfig = {
      "a11yLabel":"Email Address"
    };
    this.view.UserInformationNUO.filterDropdown.tbxDropdownKA.accessibilityConfig = {
      "a11yLabel":"Country Code"
    };
    this.view.UserInformationNUO.atxtPhoneNumber.tbxAnimatedKA.accessibilityConfig = {
      "a11yLabel":"Phone Number"
    };
    //      this.view.YesNoOptionChoser.flxYes.accessibilityConfig = {
    //       "a11yLabel":"Yes Button"
    //     };
    //      this.view.YesNoOptionChoser.flxNo.accessibilityConfig = {
    //       "a11yLabel":"No Button"
    //     };
    //      this.view.flxHeader.accessibilityConfig = {
    //       "a11yLabel":"",
    //       "a11yARIA": {
    //         "tabindex": -1  
    //       }
    //     };
    //      this.view.customHeaderNUO.accessibilityConfig = {
    //       "a11yLabel":"",
    //       "a11yARIA": {
    //         "tabindex": -1  
    //       }
    //     };
    //     this.view.customHeaderNUO.flxTop.accessibilityConfig = {
    //       "a11yLabel":"",
    //       "a11yARIA": {
    //         "tabindex": -1  
    //       }
    //     };
    //     this.view.customHeaderNUO.flxTopMain.accessibilityConfig = {
    //       "a11yLabel":"",
    //       "a11yARIA": {
    //         "tabindex": -1  
    //       }
    //     };
    this.view.flxHeader.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.customHeaderNUO.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.flxMainScroll.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.customHeaderNUO.imgLogo.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.f1.accessibilityConfig = {
      "a11yARIA": {
        "role": "main",
        "tabindex": -1  
      }
    };
    
    this.view.UserInformationNUO.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.UserInformationNUO.YesNoOptionChoser.accessibilityConfig= {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.UserInformationNUO.flxCoApplicantOptionChooser.accessibilityConfig= {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };

    this.view.UserInformationNUO.lblCoApplicant.accessibilityConfig= {
      "tagName" : "span",
      "a11yARIA": {
        "tabindex": -1  
      }
    };
    this.view.UserInformationNUO.YesNoOptionChoser.flxButtons.accessibilityConfig= {
      "a11yLabel": "Do you want to add a co-applicant?",
      "a11yARIA": {
        "role": "radiogroup",
        "tabindex": -1
      }
    };
    this.view.flxMainScroll.accessibilityConfig= {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };

    this.view.UserInformationNUO.lblSubHeaderTitle1.accessibilityConfig= {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };

    this.view.customHeaderNUO.accessibilityConfig= {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };


    /*this.view.lblHeader.accessibilityConfig = {
      "a11yARIA": {
        "role": "complementary",
        "aria-level": "1",
        "tabindex": -1 
      }
    };*/

    this.view.customfooter.lblCopyright.accessibilityConfig = {
      "a11yLabel":"",
      "a11yARIA": {
        "tabindex": -1  
      }
    };

    // Label TagNames

    this.view.customHeaderNUO.lblOnboarding.accessibilityConfig = {
      "tagName" : "span","a11yARIA": {"tabindex": -1}
    };
    this.view.lblHeader.accessibilityConfig = {
      "tagName" : "h1",
      "a11yARIA": {
        "tabindex": -1
      }
    };
    this.view.UserInformationNUO.lblSubHeaderTitle1.accessibilityConfig = {
      "tagName" : "h2","a11yARIA": {"tabindex": -1}
    };
    this.view.UserInformationNUO.lblSubHeaderTitle3.accessibilityConfig = {
      "tagName" : "h2","a11yARIA": {"tabindex": -1}
    };
    this.view.UserInformationNUO.lblQuestion.accessibilityConfig = {
      "tagName" : "h2","a11yARIA": {"tabindex": -1}
    };
    this.view.UserInformationNUO.YesNoOptionChoser.lblYes.accessibilityConfig = {
      "tagName" : "span","a11yARIA": {"tabindex": -1}
    };
    this.view.UserInformationNUO.YesNoOptionChoser.lblNo.accessibilityConfig = {
      "tagName" : "span","a11yARIA": {"tabindex": -1}
    };
    this.view.procedureForNUO.lblHeading.accessibilityConfig = {
      "tagName" : "h2","a11yARIA": {"tabindex": -1}
    };
    //this.view.UserInformationNUO.lblCoApplicant.accessibilityConfig = {      "tagName" : "div",  };
    this.view.customfooter.lblCopyright.accessibilityConfig = {
      "tagName" : "span","a11yARIA": {"tabindex": -1}
    };

    this.view.Roadmap.lblApplicationStatus.accessibilityConfig = {
      "tagName" : "span","a11yARIA": {"tabindex": -1}
    };
    this.view.Roadmap.lblApplicationStartDate.accessibilityConfig = {
      "tagName" : "span","a11yARIA": {"tabindex": -1}
    };
    this.view.Roadmap.segSections.setData ([
      {
        "lblRowName": {
          "text": "Personal Information",
          "skin": "lblTitle15",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "imgRowDone": {
          "isVisible": false
        },
        "lblRowNumber": {
          "text": "1",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "flxRowCircle": {
          "skin": "flxInProgressCircleRoadmap"
        },
        "lblInProgress": {
          "text": "In Progress",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "flxCurrentRowIndicator": {
          "skin": "flxInProgressRowRoadmap"
        },
        "imgDottedLine": {
          "isVisible": false
        },
        "flxRowContent": {
          "top": "0dp"
        },
        "height": "55dp"
      },
      {
        "lblRowName": {
          "text": "Product Selection",
          "skin": "lblTitle15",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "imgRowDone": {
          "isVisible": false
        },
        "lblRowNumber": {
          "text": "2",
          "skin": "lblTitle15",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "flxRowCircle": {
          "skin": "flxInactiveCircleRoadmap"
        },
        "lblInProgress": {
          "text": "Pending",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "flxCurrentRowIndicator": {
          "skin": "slFbox"
        },
        "imgDottedLine": {
          "isVisible": true
        },
        "flxRowContent": {
          "top": "5dp"
        }
      },
      {
        "lblRowName": {
          "text": "Verification",
          "skin": "lblTitle15",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "imgRowDone": {
          "isVisible": false
        },
        "lblRowNumber": {
          "text": "3",
          "skin": "lblTitle15",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "flxRowCircle": {
          "skin": "flxInactiveCircleRoadmap"
        },
        "lblInProgress": {
          "text": "Pending",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "flxCurrentRowIndicator": {
          "skin": "slFbox"
        },
        "imgDottedLine": {
          "isVisible": true
        },
        "flxRowContent": {
          "top": "5dp"
        }
      },
      {
        "lblRowName": {
          "text": "Submit Application",
          "skin": "lblTitle15",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "imgRowDone": {
          "isVisible": false
        },
        "lblRowNumber": {
          "text": "4",
          "skin": "lblTitle15",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "flxRowCircle": {
          "skin": "flxInactiveCircleRoadmap"
        },
        "lblInProgress": {
          "text": "Pending",
          "accessibilityConfig": {
            "tagName": "span","a11yARIA": {"tabindex": -1}
          }
        },
        "flxCurrentRowIndicator": {
          "skin": "slFbox"
        },
        "imgDottedLine": {
          "isVisible": true
        },
        "flxRowContent": {
          "top": "5dp"
        }
      }
    ]);

  },

  postShowFunc: function() {
    document.querySelectorAll('input[kwp*="frmPersonalInfod_UserInformationNUO_DateInput_tbxDateInputKA"]').forEach(function(el){el.setAttribute("inputmode","number");});
    document.querySelectorAll('img[tabindex="-1"]').forEach(function(el){el.setAttribute("alt","")});
    document.querySelectorAll('img[id="flxRoadmapRowContainer_imgDottedLine"]').forEach(function(elem){elem.setAttribute("alt","");elem.setAttribute("tabindex","-1");});
    document.querySelectorAll('img#frmPersonalInfod_Roadmap_imgDropdown').forEach(function(el){el.setAttribute("alt","");el.setAttribute("tabindex","-1");});
    //document.querySelectorAll('ul[role="grid"]').forEach(function(elem){elem.removeAttribute("tabindex");});
    document.querySelectorAll("label[kw='Button']").forEach(function(el){el.style.outlineOffset = "4px";});
    //document.querySelectorAll("input[kw='TextBox2']").forEach(function(el){el.style.outlineOffset = "4px";});
    document.querySelectorAll('h1').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('h2').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('h3').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('h4').forEach(function(el){el.removeAttribute("tabindex");});
    document.querySelectorAll('span').forEach(function(el){el.removeAttribute("tabindex");});
    //document.querySelectorAll('input[type="text"]').forEach(function(el){el.setAttribute("autoComplete","on");});
    document.querySelectorAll('input[kwp*="frmPersonalInfod_UserInformationNUO_filterDropdown_tbxDropdownKA"]').forEach(function(el){el.setAttribute("role","combobox");}); 
    document.querySelectorAll('input[kwp*="atbxFirstName_tbxAnimatedKA"]').forEach(function(el){el.setAttribute("autocomplete","given-name");});
    document.querySelectorAll('input[kwp*="atbxLastName_tbxAnimatedKA"]').forEach(function(el){el.setAttribute("autocomplete","family-name");});
    document.querySelectorAll('input[kwp*="DateInput_tbxDateInputKA"]').forEach(function(el){el.setAttribute("autocomplete","bday");});
    document.querySelectorAll('input[kwp*="atbxEmail_tbxAnimatedKA"]').forEach(function(el){el.setAttribute("autocomplete","email");});
    document.querySelectorAll('input[kwp*="filterDropdown_tbxDropdownKA"]').forEach(function(el){el.setAttribute("autocomplete","tel-country-code");el.setAttribute("aria-label","Country Code");});
    document.querySelectorAll('input[kwp*="atxtPhoneNumber_tbxAnimatedKA"]').forEach(function(el){el.setAttribute("autocomplete","tel-national");});
    document.querySelectorAll('label[kwp="frmPersonalInfod_UserInformationNUO_lblCoApplicant"]').forEach(function(el){el.setAttribute("tabindex","-1");});                                                      
    //document.querySelectorAll('div').forEach(function(el){el.removeAttribute("tabindex");});
    
    document.querySelectorAll('[tabindex="-1"]').forEach(function(elem){elem.removeAttribute("tabindex");});
    document.querySelectorAll('[kwp*="Roadmap_segSections"] ol li').forEach(
      function(elem, index){
        if (index === 0) {
          elem.setAttribute("aria-current","step");
        }
      }
    );
    this.view.UserInformationNUO.filterDropdown.tbxDropdownKA.accessibilityConfig = {
      "a11yLabel":"Country Code",
      "a11yARIA": {
        "aria-haspopup":"listbox",
        "aria-expanded":"false",
      },
      "role":"combobox"
    }; 
    document.querySelectorAll('input[role="combobox"]').forEach(function(el){el.setAttribute("autocomplete","bday");});
    makeIdUnique("flexcontainer_wrapper");
    makeIdUnique("flxRoadmapRowContainer_flxRoadmapRowContainer");
    makeIdUnique("flxRoadmapRowContainer_flxRowContent");
    makeIdUnique("flxRoadmapRowContainer_flxCurrentRowIndicator");
    makeIdUnique("flxRoadmapRowContainer_flxRowCircle");
    makeIdUnique("flxRoadmapRowContainer_lblRowNumber");
    makeIdUnique("flxRoadmapRowContainer_lblRowName");
    makeIdUnique("flxRoadmapRowContainer_imgDottedLine_span");
    makeIdUnique("flxRoadmapRowContainer_imgDottedLine");
    makeIdUnique("flxDropdownKA_flxDropdownKA");
    makeIdUnique("flxDropdownKA_flxCountry");
    makeIdUnique("flxDropdownKA_lblCountryNameKA");
    makeIdUnique("flxDropdownKA_lblLeftBracketKA");
    makeIdUnique("flxDropdownKA_lblCountryCodeKA");
    makeIdUnique("flxDropdownKA_lblRightBracketKA");
    document.querySelectorAll('ul[role="grid"] li').forEach(function(elem){elem.removeAttribute("tabindex");});
    document.querySelectorAll('div[kwp="frmPersonalInfod_UserInformationNUO_YesNoOptionChoser_flxButtons"]').forEach(function(el){el.setAttribute("role","radiogroup");});
    document.querySelectorAll('label').forEach(function(elem){
      if(elem.textContent === ""){
        elem.remove();
      }
    });
    document.querySelectorAll('div[kwp="frmPersonalInfod_UserInformationNUO_filterDropdown_segDropdownKA"] div[role="row"]').forEach(function(el){
      el.setAttribute("role","button");
    });
    document.querySelectorAll('div[kwp="frmPersonalInfod_UserInformationNUO_filterDropdown_segDropdownKA"] div[role="table"]').forEach(function(el){
      el.removeAttribute("role");
    });
  }
});