function AS_AppEvents_h971d88028ed43b9afe719243a8b2849(eventobject) {
    var self = this;
    kony.application.setApplicationBehaviors({
        buttonAsLabel: false
    });
}