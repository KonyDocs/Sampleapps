function AS_FlexContainer_c3e5c85d123843e28b3fce953a9bb9c4(eventobject) {
    var self = this;
    this.initialize();
}