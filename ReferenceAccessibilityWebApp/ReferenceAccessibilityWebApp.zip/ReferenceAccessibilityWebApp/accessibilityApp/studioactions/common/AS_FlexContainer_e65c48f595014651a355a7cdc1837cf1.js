function AS_FlexContainer_e65c48f595014651a355a7cdc1837cf1(eventobject, breakpoint) {
    var self = this;
    return self.onBreakpointChange.call(this, eventobject, breakpoint);
}