function AS_FlexContainer_da96927d15044b4fb208d5b0b62df9be(eventobject) {
    var self = this;
    return self.accessibilitconfigurations.call(this);
}