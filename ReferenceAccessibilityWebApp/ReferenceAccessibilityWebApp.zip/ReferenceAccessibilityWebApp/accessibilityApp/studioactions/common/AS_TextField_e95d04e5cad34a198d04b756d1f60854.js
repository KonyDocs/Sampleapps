function AS_TextField_e95d04e5cad34a198d04b756d1f60854(eventobject, changedtext) {
    var self = this;
}