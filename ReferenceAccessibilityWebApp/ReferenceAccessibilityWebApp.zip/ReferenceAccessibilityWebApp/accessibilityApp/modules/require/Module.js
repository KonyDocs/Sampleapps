//Type your code here
var scopePresonalInfo;