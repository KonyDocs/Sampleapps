define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnGenerateAsymmetric **/
    AS_Button_ce1d2941d13540ee9f22858f2bf8c581: function AS_Button_ce1d2941d13540ee9f22858f2bf8c581(eventobject) {
        var self = this;
        return self.generateAsymmetricKeyPair.call(this);
    },
    /** onClick defined for btnRetrievePublicKey **/
    AS_Button_g6d02cc8cbb74f1fa8940210ba277a81: function AS_Button_g6d02cc8cbb74f1fa8940210ba277a81(eventobject) {
        var self = this;
        return self.retrieveAsymmetricKey.call(this);
    },
    /** onClick defined for btnAsymmmetricEncrypt **/
    AS_Button_c537311da5b14de39a2e52378e88ec93: function AS_Button_c537311da5b14de39a2e52378e88ec93(eventobject) {
        var self = this;
        return self.asymmetricEncrypt.call(this);
    },
    /** onClick defined for btnAsymmetricDecrypt **/
    AS_Button_ad719039395e48ebb2107d475cbcfd19: function AS_Button_ad719039395e48ebb2107d475cbcfd19(eventobject) {
        var self = this;
        return self.asymmetricDecrypt.call(this);
    },
    /** onClick defined for headerButtonLeft **/
    AS_Button_f637d0145eae4d73ab6c967cadd4a23f: function AS_Button_f637d0145eae4d73ab6c967cadd4a23f(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmHome");
        ntf.navigate();
    }
});