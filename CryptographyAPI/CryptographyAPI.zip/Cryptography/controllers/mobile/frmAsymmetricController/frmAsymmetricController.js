define({ 

//Generating Asymmetric key Pair by seting all the required parameters
 generateAsymmetricKeyPair: function()
  {
    var isGenerated = kony.crypto.generateAsymmetricKeyPair({
        "alias": "Kony",
        "algo": "RSA",
        "padding": "PKCS1Padding",
        "cipher": "RSA",
        "mode": "ECB",
        "digest": "",
        "keysize": "2048",
        "publicexponent": 3      
    });
    alert("The Generated Key is " +isGenerated );
  },

  
// Performing an Asymmetric Encrypt by generating an asymmetric encrypted object 
 encryptedobject : {},

  asymmetricEncrypt: function(){
    var key = this.view.tbxasyencrypt.text;
    
      if(kony.os.deviceInfo().name=="iPhone")
    {
        encryptedobject=kony.crypto.asymmetricEncrypt("Kony", key , {
        "transformation": "RSA:OAEP:SHA1"});
    var encryptBase64foriOS = kony.convertToBase64(encryptedobject);
    alert("The Encrypted text is as follows " +encryptBase64foriOS);
    }
   else{
  encryptedobject=kony.crypto.asymmetricEncrypt("Kony", key , {
        "transformation": "RSA/ECB/PKCS1Padding"});
    var encryptBase64forAndroid = kony.convertToBase64(encryptedobject);
    alert("The Encrypted text is as follows " +encryptBase64forAndroid);
   }
  },
  
// Performing an Asymmetric Decrypt by generating an asymmetric decryption object  
  asymmetricDecrypt: function()
  {
  if(kony.os.deviceInfo().name=="iPhone")
    {
    var decryptedForiOS = kony.crypto.asymmetricDecrypt("Kony", encryptedobject, {
        "transformation": "RSA:OAEP:SHA1"});
    alert("The Decrypted Message is as follows " +decryptedForiOS);
    }
    else{
      var decryptedForAndroid = kony.crypto.asymmetricDecrypt("Kony", encryptedobject, {
        "transformation": "RSA/ECB/PKCS1Padding"});
    alert("The Decrypted Message is as follows " +decryptedForAndroid);
    }
},
  
//Retrieving the Asymmetric Public Key  
 retrieveAsymmetricPublicKey: function()
  {
  var key = kony.crypto.retrieveAsymmetricPublicKey("Kony");
    alert("The Asymmetric key is " +key);
}
  
 });