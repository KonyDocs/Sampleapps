define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0h760a3249cec4c **/
    AS_Button_ad2f01a91da14854bd99265158d06555: function AS_Button_ad2f01a91da14854bd99265158d06555(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmSymmetric");
        ntf.navigate();
    },
    /** onClick defined for Button0d5346db2200845 **/
    AS_Button_b519ed0338d845cba83a5ba4aa55ec6c: function AS_Button_b519ed0338d845cba83a5ba4aa55ec6c(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmAsymmetric");
        ntf.navigate();
    }
});