define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for headerButtonLeft **/
    AS_Button_ceb75c11638841438b4b1a315a855f77: function AS_Button_ceb75c11638841438b4b1a315a855f77(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmHome");
        ntf.navigate();
    },
    /** onClick defined for Button0a532792e8efe49 **/
    AS_Button_b01ab0f78733400d9d1686809d4b8e64: function AS_Button_b01ab0f78733400d9d1686809d4b8e64(eventobject) {
        var self = this;
        return self.Encrypt.call(this);
    },
    /** onClick defined for CopyButton0bfe6507af12d42 **/
    AS_Button_a2471a5e214d4a00bdb2dc31d867185b: function AS_Button_a2471a5e214d4a00bdb2dc31d867185b(eventobject) {
        var self = this;
        return self.decrypt.call(this);
    },
    /** onClick defined for CopyButton0dc26a5920be04d **/
    AS_Button_a71de5af16044caa80891283f5719987: function AS_Button_a71de5af16044caa80891283f5719987(eventobject) {
        var self = this;
        return self.createHashMD2.call(this);
    },
    /** onClick defined for CopyButton0i120a5fb161946 **/
    AS_Button_f84f9d969c6245bdbd6c8bec31b7398b: function AS_Button_f84f9d969c6245bdbd6c8bec31b7398b(eventobject) {
        var self = this;
        return self.createHMacHash.call(this);
    },
    /** onClick defined for CopyButton0g6b2c8da273940 **/
    AS_Button_d2a65a3a616641e0920a5d2246956862: function AS_Button_d2a65a3a616641e0920a5d2246956862(eventobject) {
        var self = this;
        return self.createPBKDF2KEY.call(this);
    },
    /** onClick defined for CopyButton0a134b0a3f8ab48 **/
    AS_Button_b00ad91524954e9e8c9b5bf7e44ebdd2: function AS_Button_b00ad91524954e9e8c9b5bf7e44ebdd2(eventobject) {
        var self = this;
        return self.createNewKey.call(this);
    },
    /** onClick defined for CopyButton0b32ce106aaf948 **/
    AS_Button_e8db818c8aaa4f4eadde4565774305b7: function AS_Button_e8db818c8aaa4f4eadde4565774305b7(eventobject) {
        var self = this;
        return self.saveTheKey.call(this);
    },
    /** onClick defined for CopyButton0cb26337c5f6442 **/
    AS_Button_e39a120167684eb68920fd7204817354: function AS_Button_e39a120167684eb68920fd7204817354(eventobject) {
        var self = this;
        return self.readKey.call(this);
    },
    /** onClick defined for CopyButton0e9e1543f06c648 **/
    AS_Button_bd3136cb084f45178a9eaeda21d0e7c7: function AS_Button_bd3136cb084f45178a9eaeda21d0e7c7(eventobject) {
        var self = this;
        return self.deleteKey.call(this);
    }
});